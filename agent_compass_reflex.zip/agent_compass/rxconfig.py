import reflex as rx

config = rx.Config(
    app_name="agent_compass",
    show_built_with_reflex=False,
)
