# Sentinel Underwriters — Agent Compass (Reflex / Python port)

A full-stack **pure-Python** (Reflex) port of the original TanStack Start /
React "agent-compass" app: an AI recruiter + P&C insurance quote-to-bind
demo with an agentic "AI Engineer" that can reconfigure the app live, an
AI claims adjuster, and live NOAA/FEMA/USGS hazard intelligence.

Original stack: TanStack Start, React, Vercel AI SDK, Cloudflare Workers.
This port: **Reflex 0.9+** (Python, compiles to React under the hood),
`httpx` for hazard data, and the official `openai` SDK pointed at the
Lovable AI Gateway (OpenAI-compatible) for all model calls.

## Project layout

```
agent_compass/
  agent_compass.py        # Page layout + all UI (hero, recruiter, 6 modules)
  state.py                 # Single rx.State: all vars + event handlers
  models.py                 # Dataclasses used as typed Var models
  styles.py                  # Design tokens ported from styles.css (oklch)
  constants.py                # Static form options / flow steps
  backend/
    ai_gateway.py              # AsyncOpenAI client -> Lovable AI Gateway
    agent_tools.py               # Tool schemas + tool-calling agent loop
    claims_ai.py                   # Claim adjudication + evidence description
    hazard.py                        # NOAA / FEMA / USGS / geocoding aggregator
    claim_stages.py                    # 5-stage claims lifecycle narrative data
  components/
    reasoning_stream.py                  # Typewriter "agent thinking" box
    hazard_panel.py                        # Hazard intelligence card
    claims_lifecycle.py                      # Human-in-the-loop claims workflow
```

## Setup

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # then fill in LOVABLE_API_KEY
reflex init             # first time only, sets up the .web/ frontend
reflex run               # http://localhost:3000
```

You need a `LOVABLE_API_KEY` (from https://lovable.dev) for the AI Engineer
chat, claim adjudication, and evidence auto-fill features to work. The
hazard intelligence panel (NOAA/FEMA/USGS/geocoding) needs no key.

## Notes on the port

- **rx.Base is gone in Reflex 0.9** — all structured Var types
  (`Persona`, `ChatMsg`, `HazardData`, `ClaimStage`, ...) are plain
  `dataclasses` in `models.py`.
- The Vercel AI SDK's `useChat` + `streamText` + tool-calling loop is
  replaced by `backend/agent_tools.run_agent_turn`, a plain async
  generator that drives the OpenAI-compatible `chat.completions` tool
  loop and yields `AgentEvent`s (`tool_start`, `tool_done`, `text_delta`,
  `done`, `error`) consumed by a Reflex `@rx.event(background=True)`
  handler, which streams updates into the UI as they happen.
- The React "typewriter" `ReasoningStream` effect is reproduced with a
  background task that reveals each reasoning step a few characters at a
  time (`State._animate_reasoning`), instead of per-character DOM updates.
- Image attachments in claims are sent as OpenAI `image_url` content
  parts (base64 data URLs) — simpler than the original's manual
  Uint8Array conversion. Non-image attachments (audio/video) are
  described by filename/type only, since arbitrary binary parts aren't
  part of the standard chat-completions content-part spec.
- All dollar figures, rating factors, and the 5-stage claims workflow
  narrative are unchanged from the original — this is a framework port,
  not a rewrite of the business logic.

## What was verified

- `python -m py_compile` on every module.
- Full import of `state.py` and `agent_compass.py`.
- `reflex init` (scaffolds `.web/`) and `reflex run --backend-only`
  start cleanly and serve `/ping` — i.e. the entire component tree
  (every page, every `rx.cond`/`rx.match`/`rx.foreach`) compiles without
  error under Reflex 0.9.7.
- Not independently verified: the actual Lovable AI Gateway calls (no
  API key available in the build environment) and a full browser-driven
  click-through of every interaction.
