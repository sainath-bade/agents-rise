"""Port of HazardPanel.tsx."""

import reflex as rx

from agent_compass import styles
from agent_compass.state import State


def _tier_color(tier: rx.Var) -> rx.Var:
    return rx.cond(tier == "High", "red", rx.cond(tier == "Elevated", "amber", "gray"))


def hazard_panel(prefix: str, address: rx.Var, context: str, fetch_event) -> rx.Component:
    data = getattr(State, f"{prefix}_data")
    loading = getattr(State, f"{prefix}_loading")
    error = getattr(State, f"{prefix}_error")
    has_data = getattr(State, f"{prefix}_has_data")

    return rx.box(
        rx.vstack(
            rx.hstack(
                rx.icon("cloud-lightning", size=16, color=styles.PRIMARY),
                rx.text("Hazard Intelligence", weight="bold"),
                rx.cond(
                    has_data,
                    rx.badge(
                        data.risk_tier, " risk · score ", data.risk_score,
                        color_scheme=_tier_color(data.risk_tier),
                    ),
                ),
                spacing="2",
                align="center",
            ),
            rx.text(
                f"Live data from NOAA NWS, FEMA OpenFEMA and USGS — used for "
                f"{'underwriting risk pricing' if context == 'underwriting' else 'claims adjudication'}.",
                size="1", color=styles.MUTED_FOREGROUND,
            ),
            rx.hstack(
                rx.text(
                    rx.cond(address != "", address, "—"),
                    size="1", color=styles.MUTED_FOREGROUND, overflow="hidden",
                    text_overflow="ellipsis", white_space="nowrap", max_width="70%",
                ),
                rx.button(
                    rx.cond(loading, rx.spinner(size="1"), rx.icon("refresh-cw", size=12)),
                    " Refresh",
                    size="1", variant="outline", on_click=fetch_event, disabled=loading,
                ),
                justify="between", width="100%", align="center",
            ),
            rx.cond(
                error != "",
                rx.box(
                    rx.text(error, size="1", color=styles.DESTRUCTIVE),
                    padding="0.5rem", border_radius="0.375rem",
                    border=f"1px solid {styles.DESTRUCTIVE}",
                    background="oklch(0.577 0.245 27.325 / 0.05)",
                ),
            ),
            rx.cond(
                (~has_data) & (~loading) & (error == ""),
                rx.text(
                    "Click Refresh to pull live NOAA alerts, FEMA disaster declarations "
                    "and USGS earthquake activity for this location.",
                    size="1", color=styles.MUTED_FOREGROUND,
                ),
            ),
            rx.cond(
                data.alerts.length() > 0,
                rx.vstack(
                    rx.text(f"NOAA active alerts (", data.alerts.length(), ")", size="1", weight="bold", color=styles.MUTED_FOREGROUND),
                    rx.foreach(
                        data.alerts,
                        lambda a: rx.box(
                            rx.text(a.event, " · ", a.severity, size="1", weight="bold"),
                            rx.text(a.headline, size="1", color=styles.MUTED_FOREGROUND),
                            padding="0.4rem", border_radius="0.375rem",
                            background="oklch(0.96 0.02 250 / 0.5)",
                            border=f"1px solid {styles.BORDER}",
                            width="100%",
                        ),
                    ),
                    spacing="1", width="100%", align_items="start",
                ),
            ),
            rx.cond(
                data.fema_disasters.length() > 0,
                rx.vstack(
                    rx.text("FEMA disaster declarations (last 24mo)", size="1", weight="bold", color=styles.MUTED_FOREGROUND),
                    rx.foreach(
                        data.fema_disasters,
                        lambda d: rx.text(
                            d.declaration_date, " ", d.incident_type, " — ", d.declaration_title,
                            " (", d.designated_area, ")", size="1",
                        ),
                    ),
                    spacing="1", width="100%", align_items="start",
                ),
            ),
            rx.cond(
                data.earthquakes.length() > 0,
                rx.vstack(
                    rx.text("USGS earthquakes (30d, 300km)", size="1", weight="bold", color=styles.MUTED_FOREGROUND),
                    rx.foreach(
                        data.earthquakes,
                        lambda q: rx.text("M", q.mag, " · ", q.place, size="1"),
                    ),
                    spacing="1", width="100%", align_items="start",
                ),
            ),
            rx.cond(
                data.forecast_periods.length() > 0,
                rx.vstack(
                    rx.text(f"NOAA forecast — ", data.forecast_city, ", ", data.forecast_state, size="1", weight="bold", color=styles.MUTED_FOREGROUND),
                    rx.grid(
                        rx.foreach(
                            data.forecast_periods,
                            lambda p: rx.box(
                                rx.text(p.name, size="1", weight="bold"),
                                rx.text(p.temperature, "°", p.temperature_unit, " · ", p.wind_speed, size="1"),
                                rx.text(p.short_forecast, size="1", color=styles.MUTED_FOREGROUND),
                                padding="0.4rem", border_radius="0.375rem",
                                background="oklch(0.96 0.02 250 / 0.3)", border=f"1px solid {styles.BORDER}",
                            ),
                        ),
                        columns="3", spacing="1", width="100%",
                    ),
                    spacing="1", width="100%", align_items="start",
                ),
            ),
            rx.cond(
                has_data & (data.sources.length() > 0),
                rx.text("Sources: ", rx.foreach(data.sources, lambda s: rx.text.span(s, " · ")), size="1", color=styles.MUTED_FOREGROUND),
            ),
            spacing="3", width="100%", align_items="start",
        ),
        **styles.CARD_STYLE,
        padding="1.25rem",
        width="100%",
    )
