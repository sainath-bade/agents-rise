"""Port of ReasoningStream.tsx — a terminal-style box that types out agent
reasoning steps one character-chunk at a time. The typewriter animation
itself lives in State (``_animate_reasoning``); this component just renders
whatever the state currently holds for a given (rendered, current, done)
triple of vars.
"""

import reflex as rx

from agent_compass import styles


def reasoning_stream(
    title: str,
    rendered: rx.Var,
    current: rx.Var,
    done: rx.Var,
) -> rx.Component:
    return rx.box(
        rx.hstack(
            rx.hstack(
                rx.icon("brain", size=16, color=styles.PRIMARY),
                rx.text(title, size="2", weight="bold"),
                spacing="2",
                align="center",
            ),
            rx.cond(
                done,
                rx.hstack(
                    rx.box(
                        width="6px", height="6px", border_radius="9999px",
                        background=styles.SUCCESS,
                    ),
                    rx.text("complete", size="1", color=styles.MUTED_FOREGROUND),
                    spacing="1",
                    align="center",
                ),
                rx.hstack(
                    rx.spinner(size="1"),
                    rx.text("thinking", size="1", color=styles.MUTED_FOREGROUND),
                    spacing="1",
                    align="center",
                ),
            ),
            justify="between",
            width="100%",
            padding="0.6rem 1rem",
            border_bottom=f"1px solid {styles.BORDER}",
        ),
        rx.box(
            rx.foreach(
                rendered,
                lambda line: rx.box(
                    rx.text.span("› ", color=styles.PRIMARY),
                    rx.text.span(line),
                    font_family="monospace",
                    font_size="0.72rem",
                    line_height="1.5",
                    color=styles.FOREGROUND,
                    padding_bottom="2px",
                ),
            ),
            rx.cond(
                current != "",
                rx.box(
                    rx.text.span("› ", color=styles.PRIMARY),
                    rx.text.span(current, color=styles.MUTED_FOREGROUND),
                    font_family="monospace",
                    font_size="0.72rem",
                ),
            ),
            rx.cond(
                (current == "") & (rendered.length() == 0),
                rx.text("Waiting for input…", size="1", color=styles.MUTED_FOREGROUND),
            ),
            max_height="16rem",
            overflow_y="auto",
            padding="0.75rem 1rem",
        ),
        border_radius="0.5rem",
        border=f"1px solid {styles.BORDER}",
        background=styles.CARD,
        box_shadow=styles.SHADOW_SOFT,
        width="100%",
    )
