"""Port of ClaimsLifecycle.tsx — the Insights Agent human-in-the-loop claims
workflow: 5 stages, each surfacing insights/hypotheses/thresholds and pausing
for an explicit human approve/override decision.
"""

import reflex as rx

from agent_compass import styles
from agent_compass.state import State


def _status_badge(status: rx.Var) -> rx.Component:
    return rx.match(
        status,
        ("approved", rx.badge("Approved", color_scheme="blue")),
        ("rejected", rx.badge("Overridden", color_scheme="red")),
        ("active", rx.badge("Awaiting decision", color_scheme="gray")),
        rx.badge("Locked", variant="outline", color_scheme="gray"),
    )


def _severity_style(sev: rx.Var) -> rx.Var:
    return rx.cond(
        sev == "critical", "critical",
        rx.cond(sev == "warn", "warn", "info"),
    )


def _insight_box(ins: rx.Var) -> rx.Component:
    return rx.box(
        rx.hstack(
            rx.icon(
                rx.cond((ins.severity == "critical") | (ins.severity == "warn"), "triangle-alert", "shield-check"),
                size=14,
            ),
            rx.text(ins.label, size="1", weight="bold"),
            spacing="1", align="center",
        ),
        rx.text(ins.detail, size="1", padding_top="2px"),
        padding="0.5rem", border_radius="0.375rem",
        border=rx.cond(
            ins.severity == "critical", f"1px solid {styles.DESTRUCTIVE}",
            rx.cond(ins.severity == "warn", "1px solid oklch(0.78 0.15 75 / 0.4)", f"1px solid {styles.PRIMARY}"),
        ),
        background=rx.cond(
            ins.severity == "critical", "oklch(0.577 0.245 27.325 / 0.06)",
            rx.cond(ins.severity == "warn", "oklch(0.78 0.15 75 / 0.1)", "oklch(0.48 0.16 255 / 0.05)"),
        ),
        width="100%",
    )


def _hypothesis_box(h: rx.Var) -> rx.Component:
    return rx.box(
        rx.hstack(rx.icon("scale", size=14, color=styles.PRIMARY), rx.text(h.title, size="1", weight="bold"), spacing="1", align="center"),
        rx.text(rx.text.span("Support: ", weight="bold"), h.support, size="1", padding_top="2px"),
        rx.text(rx.text.span("Tension: ", weight="bold"), h.tension, size="1"),
        padding="0.5rem", border_radius="0.375rem", border=f"1px solid {styles.BORDER}",
        background=styles.CARD, width="100%",
    )


def _threshold_row(t: rx.Var) -> rx.Component:
    return rx.hstack(
        rx.text(t.name, size="1", weight="medium"),
        rx.hstack(
            rx.badge(t.status, variant="outline"),
            rx.text(t.note, size="1", color=styles.MUTED_FOREGROUND),
            spacing="1", align="center",
        ),
        justify="between", padding="0.35rem 0.5rem", border_radius="0.375rem",
        border=f"1px solid {styles.BORDER}", background=styles.CARD, width="100%",
    )


def _stage_card(s: rx.Var, index: int) -> rx.Component:
    is_active = s.status == "active"
    is_approved = s.status == "approved"
    is_rejected = s.status == "rejected"
    visible = is_active | is_approved | is_rejected
    return rx.box(
        rx.box(
            rx.icon(
                rx.match(
                    s.status,
                    ("approved", "circle-check-big"),
                    ("rejected", "circle-x"),
                    ("active", "loader"),
                    "circle",
                ),
                size=18,
            ),
            position="absolute", left="-30px", top="4px",
            width="24px", height="24px", border_radius="9999px",
            border=f"1px solid {styles.BORDER}", background=styles.BACKGROUND,
            display="flex", align_items="center", justify_content="center",
        ),
        rx.vstack(
            rx.hstack(
                rx.text(s.title, weight="bold"),
                _status_badge(s.status),
                justify="between", width="100%", wrap="wrap",
            ),
            rx.text(s.agent, " · ", s.role, " · ", s.subtitle, size="1", color=styles.MUTED_FOREGROUND),
            rx.cond(
                visible,
                rx.vstack(
                    rx.text("Agent-surfaced insights", size="1", weight="bold", color=styles.MUTED_FOREGROUND),
                    rx.foreach(s.insights, _insight_box),
                    rx.cond(
                        s.hypotheses.length() > 0,
                        rx.vstack(
                            rx.text("Hypothesis evaluation", size="1", weight="bold", color=styles.MUTED_FOREGROUND, padding_top="0.5rem"),
                            rx.grid(rx.foreach(s.hypotheses, _hypothesis_box), columns="2", spacing="2", width="100%"),
                            spacing="1", width="100%", align_items="start",
                        ),
                    ),
                    rx.cond(
                        s.thresholds.length() > 0,
                        rx.vstack(
                            rx.text("Governance thresholds", size="1", weight="bold", color=styles.MUTED_FOREGROUND, padding_top="0.5rem"),
                            rx.foreach(s.thresholds, _threshold_row),
                            spacing="1", width="100%", align_items="start",
                        ),
                    ),
                    rx.cond(
                        is_active,
                        rx.box(
                            rx.hstack(rx.icon("user-check", size=14, color=styles.PRIMARY), rx.text("Human decision required", size="1", weight="bold"), spacing="1", align="center"),
                            rx.text(s.decision_prompt, size="1", color=styles.MUTED_FOREGROUND, padding_top="2px"),
                            rx.hstack(
                                rx.button(
                                    rx.icon("circle-check-big", size=14), s.approve_label,
                                    size="1",
                                    on_click=State.lifecycle_decide(s.key, index, "approved", s.approve_label),
                                ),
                                rx.button(
                                    rx.icon("circle-x", size=14), s.reject_label,
                                    size="1", variant="outline",
                                    on_click=State.lifecycle_decide(s.key, index, "rejected", s.reject_label),
                                ),
                                spacing="2", padding_top="0.5rem", wrap="wrap",
                            ),
                            padding="0.6rem", border_radius="0.375rem", border=f"1px dashed {styles.BORDER}",
                            background=styles.BACKGROUND, width="100%",
                        ),
                    ),
                    rx.cond(
                        s.decision_label != "",
                        rx.box(
                            rx.text.span(rx.cond(s.status == "approved", "Approved: ", "Overridden: "), weight="bold"),
                            s.decision_label,
                            rx.text.span(" @ ", s.decision_at, color=styles.MUTED_FOREGROUND),
                            padding="0.4rem", border_left=f"3px solid {styles.PRIMARY}",
                            background="oklch(0.96 0.02 250 / 0.5)", font_size="0.78rem", width="100%",
                        ),
                    ),
                    spacing="2", width="100%", align_items="start", padding_top="0.5rem",
                ),
            ),
            spacing="1", align_items="start",
        ),
        position="relative", padding="0.75rem", border_radius="0.375rem",
        border=rx.cond(is_active, f"1px solid {styles.PRIMARY}", rx.cond(is_rejected, f"1px solid {styles.DESTRUCTIVE}", f"1px solid {styles.BORDER}")),
        background=rx.cond(is_active, "oklch(0.48 0.16 255 / 0.04)", rx.cond(is_approved, "oklch(0.96 0.02 250 / 0.4)", styles.CARD)),
        opacity=rx.cond(is_active | is_approved | is_rejected, "1", "0.7"),
        width="100%",
    )


def claims_lifecycle() -> rx.Component:
    return rx.box(
        rx.vstack(
            rx.hstack(rx.icon("workflow", size=18, color=styles.PRIMARY), rx.text("Insights Agent — Human-in-the-Loop Claims Workflow", weight="bold"), spacing="2", align="center"),
            rx.text(
                "Five stages (FNOL → Investigation → Evaluation → Negotiation → Settlement). "
                "The agent surfaces tensions, alternatives and thresholds; the adjuster decides.",
                size="1", color=styles.MUTED_FOREGROUND,
            ),
            rx.cond(
                ~State.lifecycle_started,
                rx.box(
                    rx.text(
                        "Submit the FNOL above to launch the Insights Agent workflow. Each stage will pause for your decision.",
                        size="2", color=styles.MUTED_FOREGROUND,
                    ),
                    padding="1rem", border=f"1px solid {styles.BORDER}", border_radius="0.375rem", width="100%",
                ),
            ),
            rx.cond(
                State.lifecycle_started,
                rx.box(
                    rx.vstack(
                        rx.foreach(State.lifecycle_stages, _stage_card),
                        spacing="4", width="100%",
                    ),
                    border_left=f"1px solid {styles.BORDER}", padding_left="1.5rem", width="100%",
                ),
            ),
            rx.cond(
                State.lifecycle_halted,
                rx.box(
                    rx.text("Workflow paused by adjuster", color=styles.DESTRUCTIVE, weight="bold"),
                    rx.text("The last stage was overridden. Address the escalation offline, then resume with the alternate path.", size="1", color=styles.MUTED_FOREGROUND),
                    rx.button("Reconsider stage", size="1", variant="outline", margin_top="0.5rem", on_click=State.lifecycle_resume),
                    padding="0.75rem", border=f"1px solid {styles.DESTRUCTIVE}", border_radius="0.375rem", width="100%",
                ),
            ),
            rx.cond(
                State.lifecycle_completed,
                rx.box(
                    rx.hstack(rx.icon("circle-check-big", size=16, color=styles.PRIMARY), rx.text("Claim closed with reconstructible decision trail", weight="bold", color=styles.PRIMARY), spacing="1", align="center"),
                    rx.text("Every stage was reviewed by a human. The full audit log below can be exported for supervisor review.", size="1", color=styles.MUTED_FOREGROUND),
                    padding="0.75rem", border=f"1px solid {styles.PRIMARY}", border_radius="0.375rem", width="100%",
                ),
            ),
            rx.cond(
                State.lifecycle_log.length() > 0,
                rx.box(
                    rx.hstack(rx.icon("clipboard-check", size=16, color=styles.PRIMARY), rx.text("Auditable decision trail", weight="bold"), spacing="1", align="center"),
                    rx.foreach(
                        State.lifecycle_log,
                        lambda l: rx.hstack(
                            rx.badge(l.decision, color_scheme=rx.cond(l.decision == "approved", "blue", "red")),
                            rx.text(l.stage_title, weight="medium", size="1"),
                            rx.text("— ", l.label, size="1", color=styles.MUTED_FOREGROUND),
                            rx.spacer(),
                            rx.text(l.at, size="1", color=styles.MUTED_FOREGROUND),
                            width="100%", wrap="wrap",
                        ),
                    ),
                    padding="0.75rem", border=f"1px solid {styles.BORDER}", border_radius="0.375rem", width="100%",
                ),
            ),
            spacing="4", width="100%", align_items="start",
        ),
        **styles.CARD_STYLE,
        padding="1.25rem",
        width="100%",
    )
