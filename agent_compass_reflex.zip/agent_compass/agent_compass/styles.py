"""Design tokens ported from the original ``src/styles.css`` (oklch design
system). Modern browsers support the ``oklch()`` CSS function directly, so
the original values are reused verbatim rather than converted to hex.
"""

BACKGROUND = "oklch(0.985 0.005 240)"
FOREGROUND = "oklch(0.18 0.04 250)"
CARD = "oklch(1 0 0)"
PRIMARY = "oklch(0.48 0.16 255)"
PRIMARY_FOREGROUND = "oklch(0.99 0 0)"
SECONDARY = "oklch(0.96 0.02 250)"
SECONDARY_FOREGROUND = "oklch(0.25 0.05 255)"
MUTED_FOREGROUND = "oklch(0.5 0.03 255)"
ACCENT = "oklch(0.92 0.06 200)"
DESTRUCTIVE = "oklch(0.577 0.245 27.325)"
BORDER = "oklch(0.9 0.015 250)"
SUCCESS = "oklch(0.65 0.16 155)"
WARNING = "oklch(0.78 0.15 75)"

GRADIENT_HERO = (
    "linear-gradient(135deg, oklch(0.48 0.16 255), oklch(0.65 0.18 250) 60%, oklch(0.78 0.14 200))"
)
GRADIENT_CARD = "linear-gradient(160deg, oklch(1 0 0), oklch(0.97 0.02 250))"
SHADOW_ELEGANT = "0 20px 50px -20px oklch(0.48 0.16 255 / 0.35)"
SHADOW_SOFT = "0 6px 24px -8px oklch(0.4 0.05 255 / 0.18)"

CARD_STYLE = {"box_shadow": SHADOW_SOFT, "border_radius": "0.75rem", "border": f"1px solid {BORDER}"}
CARD_STYLE_ELEGANT = {"box_shadow": SHADOW_ELEGANT, "border_radius": "0.75rem", "border": f"1px solid {BORDER}"}
CARD_STYLE_GRADIENT = {**CARD_STYLE_ELEGANT, "background": GRADIENT_CARD}

BADGE_WARN = {
    "border": "1px solid oklch(0.78 0.15 75 / 0.4)",
    "background": "oklch(0.78 0.15 75 / 0.1)",
    "color": "oklch(0.45 0.13 75)",
}
BADGE_CRITICAL = {
    "border": f"1px solid {DESTRUCTIVE} / 0.4",
    "background": f"{DESTRUCTIVE} / 0.1".replace("oklch(0.577 0.245 27.325) / 0.1", "oklch(0.577 0.245 27.325 / 0.1)"),
    "color": DESTRUCTIVE,
}
BADGE_INFO = {
    "border": "1px solid oklch(0.48 0.16 255 / 0.3)",
    "background": "oklch(0.48 0.16 255 / 0.05)",
    "color": PRIMARY,
}
