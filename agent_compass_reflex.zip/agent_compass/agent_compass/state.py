from __future__ import annotations

import asyncio
import dataclasses
import random
import uuid
from datetime import datetime, date

import reflex as rx

from agent_compass.backend.agent_tools import run_agent_turn
from agent_compass.backend.claim_stages import build_stages
from agent_compass.backend.claims_ai import adjudicate_claim, describe_evidence
from agent_compass.backend.hazard import aggregate_hazard_data
from agent_compass.constants import FIRST_NAMES, LAST_NAMES, REGIONS, ROLE_DATA, FLOW_STEPS
from agent_compass.models import (
    ChatMsg,
    ClaimAttachment,
    ClaimStage,
    CodePatch,
    DecisionLogEntry,
    ForecastPeriod,
    HazardAlert,
    HazardData,
    HazardDisaster,
    HazardQuake,
    Indication,
    Persona,
    PricingRule,
    ToolCallView,
    WorkflowPatch,
)

TYPE_CHUNK = 3          # characters revealed per animation tick
TYPE_DELAY = 0.018       # seconds between ticks
STEP_PAUSE = 0.22        # seconds pause between reasoning steps


class State(rx.State):
    # ==================================================================
    # Recruiter
    # ==================================================================
    role: str = "Underwriter"
    persona: Persona = Persona(
        name="Priya Hayashi",
        role="Underwriter",
        tagline="Underwriter · Great Lakes · 12 yrs",
        years_exp=12,
        region="Great Lakes",
        specialties=["Habitational", "Manufacturing"],
        strengths=["Risk selection", "Loss-trend analysis", "Decisive judgement"],
        summary=(
            "Priya Hayashi was selected because they're balances appetite, exposure and growth "
            "with a sharp instinct for which submissions will season profitably. With 12 years "
            "anchored in the Great Lakes market and depth in Habitational & Manufacturing, they "
            "bring the temperament and technical chops this desk needs from day one."
        ),
    )
    recruit_run: int = 0
    recruiting_steps: list[str] = []
    recruit_reasoning_rendered: list[str] = []
    recruit_reasoning_current: str = ""
    recruit_reasoning_done: bool = True

    @rx.event
    def set_role(self, value: str):
        self.role = value

    @rx.event(background=True)
    async def generate_persona(self):
        async with self:
            role = self.role
        data = ROLE_DATA[role]
        name = f"{random.choice(FIRST_NAMES)} {random.choice(LAST_NAMES)}"
        years_exp = 3 + random.randint(0, 17)
        region = random.choice(REGIONS)
        specialties = random.sample(data["specialties"], k=min(2, len(data["specialties"])))
        strengths = random.sample(data["strengths"], k=min(3, len(data["strengths"])))
        tagline = f"{role} · {region} · {years_exp} yrs"
        summary = (
            f"{name} was selected because they're {data['blurb']}. With {years_exp} years "
            f"anchored in the {region} market and depth in {' & '.join(specialties)}, they "
            "bring the temperament and technical chops this desk needs from day one."
        )
        persona = Persona(
            name=name, role=role, tagline=tagline, years_exp=years_exp, region=region,
            specialties=specialties, strengths=strengths, summary=summary,
        )
        steps = [
            f"Opening requisition for {role} desk…",
            f"Scanning talent graph: 14,820 licensed candidates in {region}.",
            f"Filtering: {years_exp}+ yrs, {' & '.join(specialties)} specialty match.",
            "Cross-checking E&O history, license status (NIPR), and carrier appointments.",
            f"Scoring soft-skills from interview transcripts: {', '.join(strengths)}.",
            f"Top match: {name} — fit score 0.92. Drafting offer brief.",
            f"Decision: extend offer — {role} role, {region} territory.",
        ]
        async with self:
            self.persona = persona
            self.recruiting_steps = steps
            self.recruit_run += 1
        await self._animate_reasoning(steps, "recruit_reasoning")

    async def _animate_reasoning(self, steps: list[str], prefix: str):
        async with self:
            setattr(self, f"{prefix}_rendered", [])
            setattr(self, f"{prefix}_current", "")
            setattr(self, f"{prefix}_done", False)
            if prefix == "intake_reasoning":
                self.reasoning_done = False
        rendered: list[str] = []
        for step in steps:
            for i in range(TYPE_CHUNK, len(step) + TYPE_CHUNK, TYPE_CHUNK):
                async with self:
                    setattr(self, f"{prefix}_current", step[:i])
                await asyncio.sleep(TYPE_DELAY)
            rendered.append(step)
            async with self:
                setattr(self, f"{prefix}_rendered", list(rendered))
                setattr(self, f"{prefix}_current", "")
            await asyncio.sleep(STEP_PAUSE)
        async with self:
            setattr(self, f"{prefix}_done", True)
            if prefix == "intake_reasoning":
                self.reasoning_done = True

    # ==================================================================
    # Modules / Business Owner control panel
    # ==================================================================
    module: str = "Business Owner"
    enabled_modules: dict[str, bool] = {
        "AI Engineer": True, "Quotes": True, "Policy": True, "Claims": True, "Actuarial": True,
    }
    premium_multiplier: float = 1.0
    premium_reason: str = ""
    default_coverage: str = ""
    default_autonomy: str = ""
    directives: dict[str, str] = {}
    custom_rules: list[PricingRule] = []
    workflow_patches: list[WorkflowPatch] = []
    code_patches: list[CodePatch] = []
    ai_change_log: list[str] = []

    @rx.event
    def set_module(self, value: str):
        gated = {"Quotes", "Policy", "Claims", "Actuarial", "AI Engineer"}
        if value in gated and not self.enabled_modules.get(value, True):
            return
        self.module = value

    @rx.event
    def set_module_enabled(self, key: str, value: bool):
        self.enabled_modules = {**self.enabled_modules, key: value}

    def _apply_tool_effect(self, applied: dict):
        kind = applied.get("kind")
        if kind == "moduleEnabled":
            self.enabled_modules = {**self.enabled_modules, applied["module"]: applied["enabled"]}
        elif kind == "premiumMultiplier":
            self.premium_multiplier = float(applied["multiplier"])
            self.premium_reason = applied.get("reason", "")
        elif kind == "defaultCoverage":
            level = applied.get("level")
            self.default_coverage = level or ""
            if level:
                self.coverage_level = level
        elif kind == "defaultAutonomy":
            autonomy = applied.get("autonomy")
            self.default_autonomy = autonomy or ""
            if autonomy:
                self.autonomy = autonomy
        elif kind == "directive":
            self.directives = {**self.directives, applied["module"]: applied["directive"]}
        elif kind == "pricingRule":
            rule = PricingRule(
                id=str(uuid.uuid4()), name=applied["name"], line=applied["line"],
                adjustment=float(applied["adjustment"]), reason=applied.get("reason", ""),
            )
            self.custom_rules = [*self.custom_rules, rule]
        elif kind == "workflowPatch":
            patch = WorkflowPatch(
                id=str(uuid.uuid4()), patch=applied["patch"], module=applied["module"],
                note=applied.get("note", ""),
            )
            self.workflow_patches = [*self.workflow_patches, patch]
        elif kind == "codePatch":
            cp = CodePatch(
                id=str(uuid.uuid4()), file=applied["file"], summary=applied["summary"],
                diff=applied["diff"], module=applied["module"], staged_at=applied.get("stagedAt", ""),
            )
            self.code_patches = [*self.code_patches, cp]

    # ------------------------------------------------------------------
    # Business Owner chat
    # ------------------------------------------------------------------
    owner_messages: list[ChatMsg] = []
    owner_input: str = ""
    owner_busy: bool = False
    owner_error: str = ""

    @rx.event
    def set_owner_input(self, value: str):
        self.owner_input = value

    @rx.event(background=True)
    async def send_owner_message(self):
        await self._run_chat("owner", mode="business-owner")

    # ------------------------------------------------------------------
    # AI Engineer chat
    # ------------------------------------------------------------------
    engineer_messages: list[ChatMsg] = []
    engineer_input: str = ""
    engineer_busy: bool = False
    engineer_error: str = ""

    @rx.event
    def set_engineer_input(self, value: str):
        self.engineer_input = value

    @rx.event(background=True)
    async def send_engineer_message(self):
        await self._run_chat("engineer", mode="engineer")

    async def _run_chat(self, which: str, mode: str):
        msgs_attr, input_attr, busy_attr, err_attr = (
            f"{which}_messages", f"{which}_input", f"{which}_busy", f"{which}_error",
        )
        async with self:
            text = getattr(self, input_attr).strip()
            busy = getattr(self, busy_attr)
            if not text or busy:
                return
            history_msgs = list(getattr(self, msgs_attr))
            history = [
                {"role": m.role, "content": m.text} for m in history_msgs if m.text
            ]
            new_msgs = [*history_msgs, ChatMsg(id=str(uuid.uuid4()), role="user", text=text)]
            setattr(self, msgs_attr, new_msgs)
            setattr(self, input_attr, "")
            setattr(self, busy_attr, True)
            setattr(self, err_attr, "")

        assistant_id = str(uuid.uuid4())
        async with self:
            msgs = [*getattr(self, msgs_attr), ChatMsg(id=assistant_id, role="assistant", text="", tool_calls=[])]
            setattr(self, msgs_attr, msgs)

        async for event in run_agent_turn(history, text, mode=mode):
            async with self:
                msgs = list(getattr(self, msgs_attr))
                idx = next((i for i, m in enumerate(msgs) if m.id == assistant_id), None)
                if idx is None:
                    continue
                msg = msgs[idx]
                if event.kind == "tool_start":
                    tool_calls = [*msg.tool_calls, ToolCallView(tool=event.tool, message="", done=False)]
                    msgs[idx] = dataclasses.replace(msg, tool_calls=tool_calls)
                elif event.kind == "tool_done":
                    tool_calls = list(msg.tool_calls)
                    for i in range(len(tool_calls) - 1, -1, -1):
                        if tool_calls[i].tool == event.tool and not tool_calls[i].done:
                            tool_calls[i] = ToolCallView(tool=event.tool, message=event.message, done=True)
                            break
                    msgs[idx] = dataclasses.replace(msg, tool_calls=tool_calls)
                    if event.applied:
                        self._apply_tool_effect(event.applied)
                    if event.message:
                        self.ai_change_log = [*self.ai_change_log, event.message]
                elif event.kind == "text_delta":
                    msgs[idx] = dataclasses.replace(msg, text=msg.text + event.text)
                elif event.kind == "error":
                    setattr(self, err_attr, event.error)
                setattr(self, msgs_attr, msgs)

        async with self:
            setattr(self, busy_attr, False)

    # ==================================================================
    # Quotes
    # ==================================================================
    quote_line: str = "Auto"
    insured_name: str = "Jordan Mitchell"
    insured_entity: str = "Vehicle"
    address: str = "482 Elm Street, Austin, TX 78704"
    tiv: int = 35_000
    prior_losses: int = 1

    vehicle_year: int = 2022
    vehicle_make: str = "Toyota"
    vehicle_model: str = "RAV4"
    vin: str = "JTMRFREV5ND123456"
    autonomy: str = "Human-Driven"
    driver_age_band: str = "25-64"
    mileage_band: str = "7,500 – 15,000 mi/yr"
    usage: str = "Commute"
    loss_history: str = "2023 — minor rear-end collision, $3,200 paid"
    coverage_level: str = "Standard"
    liability_limit: str = "100/300/100"
    deductible: int = 500

    active_step: str = "intake"
    quote_submitted: bool = False
    quote_run_id: int = 0

    reasoning_done: bool = True
    intake_reasoning_rendered: list[str] = []
    intake_reasoning_current: str = ""
    intake_reasoning_done: bool = True

    @rx.event
    def set_quote_line(self, value: str):
        self.quote_line = value
        if value == "Auto":
            self.insured_entity = "Vehicle"
            self.tiv = 35_000
        else:
            self.insured_entity = "Business" if value == "Workers' Comp" else "Property"
            self.tiv = 2_500_000

    @rx.event
    def set_insured_name(self, value: str):
        self.insured_name = value

    @rx.event
    def set_address(self, value: str):
        self.address = value

    @rx.event
    def set_insured_entity(self, value: str):
        self.insured_entity = value

    @rx.event
    def set_tiv(self, value: str):
        try:
            self.tiv = max(0, int(float(value or 0)))
        except ValueError:
            pass

    @rx.event
    def set_vehicle_year(self, value: str):
        self.vehicle_year = int(value)

    @rx.event
    def set_vehicle_make(self, value: str):
        self.vehicle_make = value

    @rx.event
    def set_vehicle_model(self, value: str):
        self.vehicle_model = value

    @rx.event
    def set_vin(self, value: str):
        import re
        self.vin = re.sub(r"[^A-HJ-NPR-Z0-9]", "", value.upper())[:17]

    @rx.event
    def set_autonomy(self, value: str):
        self.autonomy = value

    @rx.event
    def set_driver_age_band(self, value: str):
        self.driver_age_band = value

    @rx.event
    def set_mileage_band(self, value: str):
        self.mileage_band = value

    @rx.event
    def set_usage(self, value: str):
        self.usage = value

    @rx.event
    def set_loss_history(self, value: str):
        self.loss_history = value

    @rx.event
    def set_coverage_level(self, value: str):
        self.coverage_level = value

    @rx.event
    def set_liability_limit(self, value: str):
        self.liability_limit = value

    @rx.event
    def set_deductible(self, value: str):
        self.deductible = int(value)

    @rx.event
    def set_prior_losses(self, value: str):
        try:
            self.prior_losses = min(50, max(0, int(float(value or 0))))
        except ValueError:
            pass

    @rx.event
    def set_active_step(self, key: str):
        self.active_step = key

    @rx.event
    def step_back(self):
        idx = next((i for i, s in enumerate(FLOW_STEPS) if s["key"] == self.active_step), 0)
        if idx > 0:
            self.active_step = FLOW_STEPS[idx - 1]["key"]

    @rx.event
    def step_forward(self):
        idx = next((i for i, s in enumerate(FLOW_STEPS) if s["key"] == self.active_step), 0)
        if idx < len(FLOW_STEPS) - 1:
            self.active_step = FLOW_STEPS[idx + 1]["key"]

    @rx.event(background=True)
    async def submit_intake(self):
        async with self:
            self.quote_submitted = True
            self.quote_run_id += 1
            self.active_step = "intake"
            steps = self._compute_intake_steps()
        await self._animate_reasoning(steps, "intake_reasoning")
        async with self:
            address = self.address
        if address:
            await self._fetch_hazard("hazard_uw", address)

    def _compute_intake_steps(self) -> list[str]:
        ind = self.indication
        refer = ind.loss_ratio >= 65
        is_auto = self.quote_line == "Auto"
        vehicle = f"{self.vehicle_year} {self.vehicle_make} {self.vehicle_model}"
        steps = [f"Intake received: {self.insured_name} — {self.quote_line} insurance application."]
        steps.append(
            f"Garaging address geocoded: {self.address}. Territory factor pulled."
            if is_auto else f"Risk address verified: {self.address}."
        )
        if is_auto:
            steps.append(f"VIN {self.vin or '—'} decoded → {vehicle}. Symbol & class code resolved.")
        else:
            steps.append(f"Insured entity: {self.insured_entity} — schedule attached, COPE captured.")
        if is_auto:
            if self.autonomy == "Self-Driving":
                steps.append(
                    "Autonomous vehicle detected — applying SAE L4 frequency credit (-45%), "
                    "cyber/software liability load (+18%) and sensor severity load (+22%). "
                    "Driver age waived."
                )
            else:
                da = self._driver_age()
                tier = "youthful operator surcharge" if da < 25 else ("senior tier review" if da >= 65 else "standard tier")
                steps.append(f"Driver profile: age band {self.driver_age_band} → {tier}.")
        else:
            steps.append("Operations classified — class code mapped to carrier appetite.")
        if is_auto:
            steps.append(f"Usage profile: {self.usage}, {self.mileage_band}. Telematics consent flagged for UBI discount.")
        else:
            steps.append(f"Exposure base captured: TIV ${self.tiv:,}.")
        if is_auto:
            steps.append(
                f"Coverage selected: {self.coverage_level} · BI/PD {self.liability_limit} · "
                f"${self.deductible} deductible."
            )
        else:
            steps.append("Coverage form selected and limits validated.")
        lh = self.loss_history
        lh_short = lh[:60] + "…" if len(lh) > 60 else lh
        steps.append(f'MVR / loss history pulled: {self.prior_losses} prior loss(es) — "{lh_short}"')
        steps.append(
            f"Carrier appetite ✓. Projected loss ratio {ind.loss_ratio}% "
            f"{'(above target)' if refer else '(within target)'}."
        )
        steps.append(
            f"Routing to {self.persona.name} for underwriting judgement and possible counter-offer."
            if refer else "Auto-quote eligible. Generating bindable indication for the broker."
        )
        return steps

    def _driver_age(self) -> int:
        return {"16-20": 18, "21-24": 22, "25-64": 34, "65+": 70}.get(self.driver_age_band, 34)

    @rx.var(cache=True)
    def is_auto(self) -> bool:
        return self.quote_line == "Auto"

    @rx.var(cache=True)
    def active_index(self) -> int:
        return next((i for i, s in enumerate(FLOW_STEPS) if s["key"] == self.active_step), 0)

    @rx.var(cache=True)
    def indication(self) -> Indication:
        line = self.quote_line
        is_auto = line == "Auto"
        base_rate = 0.038 if is_auto else 0.0042 if line == "Commercial Property" else 0.0031 if line == "General Liability" else 0.0028

        mb = self.mileage_band
        mileage_load = 0.85 if mb.startswith("Under") else 1.0 if mb.startswith("7,500") else 1.15 if mb.startswith("15,000") else 1.3
        usage_load = 0.9 if self.usage == "Pleasure" else 1.0 if self.usage == "Commute" else 1.2
        loss_load = 1 + self.prior_losses * (0.15 if is_auto else 0.08)
        driver_age = self._driver_age()
        age_load = 1.7 if driver_age < 21 else 1.35 if driver_age < 25 else 1.0 if driver_age < 65 else 1.15
        cov = self.coverage_level
        coverage_load = 0.7 if cov == "State Minimum" else 1.0 if cov == "Standard" else 1.25 if cov == "Full Coverage" else 1.5
        deductible_load = 0.9 if self.deductible >= 1000 else 1.0 if self.deductible >= 500 else 1.12

        is_self_driving = is_auto and self.autonomy == "Self-Driving"
        autonomy_freq_credit = 0.55 if is_self_driving else 1.0
        cyber_load = 1.18 if is_self_driving else 1.0
        sensor_load = 1.22 if is_self_driving else 1.0
        effective_age_load = 1.0 if is_self_driving else age_load

        auto_factor = (
            mileage_load * usage_load * effective_age_load * coverage_load * deductible_load
            * autonomy_freq_credit * cyber_load * sensor_load
        ) if is_auto else 1.0

        rule_factor = 1.0
        for r in self.custom_rules:
            if r.line == "All" or r.line == line:
                rule_factor *= (1 + r.adjustment)

        premium = round(self.tiv * base_rate * loss_load * auto_factor * self.premium_multiplier * rule_factor)
        loss_ratio = min(95, round((40 if is_auto else 35) * (0.7 if is_self_driving else 1) + self.prior_losses * (11 if is_auto else 9)))
        return Indication(premium=premium, loss_ratio=loss_ratio, base_rate=base_rate)

    # ------------------------------------------------------------------
    # Hazard panel — underwriting (Quotes)
    # ------------------------------------------------------------------
    hazard_uw_data: HazardData = HazardData()
    hazard_uw_loading: bool = False
    hazard_uw_error: str = ""
    hazard_uw_has_data: bool = False

    @rx.event(background=True)
    async def fetch_uw_hazard(self):
        await self._fetch_hazard("hazard_uw", self.address)

    async def _fetch_hazard(self, prefix: str, address: str):
        if not address.strip():
            async with self:
                setattr(self, f"{prefix}_error", "Address required")
            return
        async with self:
            setattr(self, f"{prefix}_loading", True)
            setattr(self, f"{prefix}_error", "")
        try:
            data = await aggregate_hazard_data(address=address)
        except Exception as e:  # noqa: BLE001
            async with self:
                setattr(self, f"{prefix}_loading", False)
                setattr(self, f"{prefix}_error", str(e))
            return
        async with self:
            if not data.ok:
                setattr(self, f"{prefix}_error", data.error or "Failed to fetch hazard data")
            else:
                setattr(self, f"{prefix}_data", data)
                setattr(self, f"{prefix}_has_data", True)
            setattr(self, f"{prefix}_loading", False)

    # ==================================================================
    # Policy
    # ==================================================================
    policy_number: str = "AUTO-2024-00831"
    policy_insured_name: str = "Jordan Mitchell"
    policy_request_type: str = "Endorsement"
    policy_effective_date: str = str(date.today())
    policy_notes: str = "Add second vehicle to existing auto policy."
    policy_submitted: bool = False
    policy_submitted_summary: str = ""

    @rx.event
    def set_policy_number(self, value: str):
        self.policy_number = value

    @rx.event
    def set_policy_insured_name(self, value: str):
        self.policy_insured_name = value

    @rx.event
    def set_policy_request_type(self, value: str):
        self.policy_request_type = value

    @rx.event
    def set_policy_effective_date(self, value: str):
        self.policy_effective_date = value

    @rx.event
    def set_policy_notes(self, value: str):
        self.policy_notes = value

    @rx.event
    def submit_policy_request(self):
        self.policy_submitted = True
        self.policy_submitted_summary = (
            f"{self.policy_request_type} for policy {self.policy_number} "
            f"({self.policy_insured_name}) effective {self.policy_effective_date}."
        )

    # ==================================================================
    # Claims — FNOL intake
    # ==================================================================
    claim_claimant_name: str = "Jordan Mitchell"
    claim_policy_number: str = "AUTO-2024-00831"
    claim_loss_type: str = "Auto Collision"
    claim_date_of_loss: str = str(date.today())
    claim_location: str = "I-35 N, Austin, TX"
    claim_description: str = (
        "Insured was rear-ended at a stoplight. Reports neck pain and visible bumper/trunk damage."
    )
    claim_estimated_amount: int = 4800
    claim_injuries: str = "Soft tissue — neck"
    claim_police_report: str = "TX-2026-44821"
    claim_third_party: str = "Yes — other driver issued citation"

    claim_attachments: list[ClaimAttachment] = []
    adjudicating: bool = False
    adjudication: str = ""
    adjudication_error: str = ""
    describing_evidence: bool = False
    describe_error: str = ""
    lifecycle_run_id: int = 0

    @rx.event
    def set_claim_claimant_name(self, value: str):
        self.claim_claimant_name = value

    @rx.event
    def set_claim_policy_number(self, value: str):
        self.claim_policy_number = value

    @rx.event
    def set_claim_loss_type(self, value: str):
        self.claim_loss_type = value

    @rx.event
    def set_claim_date_of_loss(self, value: str):
        self.claim_date_of_loss = value

    @rx.event
    def set_claim_location(self, value: str):
        self.claim_location = value

    @rx.event
    def set_claim_description(self, value: str):
        self.claim_description = value

    @rx.event
    def set_claim_estimated_amount(self, value: str):
        try:
            self.claim_estimated_amount = int(float(value or 0))
        except ValueError:
            pass

    @rx.event
    def set_claim_injuries(self, value: str):
        self.claim_injuries = value

    @rx.event
    def set_claim_police_report(self, value: str):
        self.claim_police_report = value

    @rx.event
    def set_claim_third_party(self, value: str):
        self.claim_third_party = value

    @rx.event
    def remove_attachment(self, index: int):
        atts = list(self.claim_attachments)
        if 0 <= index < len(atts):
            atts.pop(index)
        self.claim_attachments = atts

    @rx.event
    async def handle_claim_upload(self, files: list[rx.UploadFile]):
        import base64
        import mimetypes

        new_atts = list(self.claim_attachments)
        for file in files:
            data = await file.read()
            if len(data) > 12 * 1024 * 1024:
                continue
            media_type = file.content_type or mimetypes.guess_type(file.name or "")[0] or "application/octet-stream"
            b64 = base64.b64encode(data).decode("ascii")
            data_url = f"data:{media_type};base64,{b64}"
            new_atts.append(
                ClaimAttachment(name=file.name or "attachment", media_type=media_type, size=len(data), data_url=data_url)
            )
        self.claim_attachments = new_atts

    def _claim_dict(self) -> dict:
        return {
            "claimantName": self.claim_claimant_name,
            "policyNumber": self.claim_policy_number,
            "lossType": self.claim_loss_type,
            "dateOfLoss": self.claim_date_of_loss,
            "location": self.claim_location,
            "description": self.claim_description,
            "estimatedAmount": self.claim_estimated_amount,
            "injuries": self.claim_injuries,
            "policeReport": self.claim_police_report,
            "thirdParty": self.claim_third_party,
        }

    def _attachments_dicts(self) -> list[dict]:
        return [
            {"name": a.name, "media_type": a.media_type, "data_url": a.data_url}
            for a in self.claim_attachments
        ]

    @rx.event(background=True)
    async def run_adjudication(self):
        async with self:
            self.adjudicating = True
            self.adjudication = ""
            self.adjudication_error = ""
            self.lifecycle_run_id += 1
            self.lifecycle_current_idx = 0
            self.lifecycle_decisions = {}
            self.lifecycle_log = []
            self.lifecycle_halted = False
            claim = self._claim_dict()
            atts = self._attachments_dicts()
        ok, result = await adjudicate_claim(claim, atts)
        async with self:
            if ok:
                self.adjudication = result
            else:
                self.adjudication_error = result
            self.adjudicating = False

    @rx.event(background=True)
    async def run_describe_evidence(self):
        async with self:
            if not self.claim_attachments:
                return
            self.describing_evidence = True
            self.describe_error = ""
            claim = self._claim_dict()
            atts = self._attachments_dicts()
        ok, result = await describe_evidence(claim, atts)
        async with self:
            if ok:
                self.claim_description = result
            else:
                self.describe_error = result
            self.describing_evidence = False

    # ------------------------------------------------------------------
    # Hazard panel — claims
    # ------------------------------------------------------------------
    hazard_claims_data: HazardData = HazardData()
    hazard_claims_loading: bool = False
    hazard_claims_error: str = ""
    hazard_claims_has_data: bool = False

    @rx.event(background=True)
    async def fetch_claims_hazard(self):
        await self._fetch_hazard("hazard_claims", self.claim_location)

    # ------------------------------------------------------------------
    # Claims lifecycle (Insights Agent, human-in-the-loop)
    # ------------------------------------------------------------------
    lifecycle_current_idx: int = -1
    lifecycle_decisions: dict[str, str] = {}
    lifecycle_log: list[DecisionLogEntry] = []
    lifecycle_halted: bool = False

    @rx.var(cache=True)
    def lifecycle_started(self) -> bool:
        return self.lifecycle_run_id > 0

    @rx.var(cache=True)
    def lifecycle_stages(self) -> list[ClaimStage]:
        stages = build_stages(
            self.claim_claimant_name, self.claim_policy_number,
            self.claim_location, float(self.claim_estimated_amount),
        )
        out = []
        for i, s in enumerate(stages):
            decision = self.lifecycle_decisions.get(s.key)
            if decision:
                status = decision
            elif i == self.lifecycle_current_idx and not self.lifecycle_halted:
                status = "active"
            else:
                status = "locked"
            log_entry = next((l for l in self.lifecycle_log if l.stage_key == s.key), None)
            out.append(
                dataclasses.replace(
                    s, status=status,
                    decision_label=log_entry.label if log_entry else "",
                    decision_at=log_entry.at if log_entry else "",
                )
            )
        return out

    @rx.var(cache=True)
    def lifecycle_completed(self) -> bool:
        stages = build_stages(
            self.claim_claimant_name, self.claim_policy_number,
            self.claim_location, float(self.claim_estimated_amount),
        )
        if self.lifecycle_current_idx < len(stages):
            return False
        return all(v == "approved" for v in self.lifecycle_decisions.values())

    @rx.event
    def lifecycle_decide(self, stage_key: str, index: int, decision: str, label: str):
        self.lifecycle_decisions = {**self.lifecycle_decisions, stage_key: decision}
        entry = DecisionLogEntry(
            stage_key=stage_key,
            stage_title=next((s.title for s in self.lifecycle_stages if s.key == stage_key), stage_key),
            decision=decision, label=label, at=datetime.now().strftime("%I:%M:%S %p"),
        )
        self.lifecycle_log = [*self.lifecycle_log, entry]
        num_stages = len(build_stages(self.claim_claimant_name, self.claim_policy_number, self.claim_location, float(self.claim_estimated_amount)))
        if decision == "approved":
            self.lifecycle_current_idx = index + 1 if index < num_stages - 1 else num_stages
        else:
            self.lifecycle_halted = True

    @rx.event
    def lifecycle_resume(self):
        self.lifecycle_halted = False
        if not self.lifecycle_log:
            return
        last = self.lifecycle_log[-1]
        decisions = {**self.lifecycle_decisions}
        decisions.pop(last.stage_key, None)
        self.lifecycle_decisions = decisions
        stages = build_stages(self.claim_claimant_name, self.claim_policy_number, self.claim_location, float(self.claim_estimated_amount))
        self.lifecycle_current_idx = next((i for i, s in enumerate(stages) if s.key == last.stage_key), 0)
