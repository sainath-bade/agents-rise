"""Static, non-reactive constants. These never change at runtime so they are
plain Python data (not State vars) rendered with normal Python loops.
"""

ROLE_DATA = {
    "Agent": {
        "specialties": ["Personal Auto", "Homeowners", "Umbrella"],
        "strengths": ["Client empathy", "Cross-sell instincts", "Local market depth"],
        "blurb": "trusted at the kitchen table, fluent in carrier appetite, and obsessed with first-call resolution",
    },
    "Broker": {
        "specialties": ["Commercial Property", "General Liability", "Workers' Comp"],
        "strengths": ["Carrier negotiation", "Wholesale relationships", "Program design"],
        "blurb": "moves complex risks across markets quickly and pulls capacity that others can't",
    },
    "Underwriter": {
        "specialties": ["Middle Market Property", "Habitational", "Manufacturing"],
        "strengths": ["Risk selection", "Loss-trend analysis", "Decisive judgement"],
        "blurb": "balances appetite, exposure and growth with a sharp instinct for which submissions will season profitably",
    },
    "Pricing Actuary": {
        "specialties": ["Loss Reserving", "Cat Modeling", "Rate Indications"],
        "strengths": ["GLM modeling", "Python/R", "Regulatory filings"],
        "blurb": "translates messy claims data into rate plans regulators approve and underwriters trust",
    },
    "Claims Adjuster": {
        "specialties": ["Property", "Bodily Injury", "Subrogation"],
        "strengths": ["Negotiation", "Coverage analysis", "Empathy under pressure"],
        "blurb": "closes files fairly and fast, keeping LAE down without burning insureds",
    },
    "Risk Engineer": {
        "specialties": ["Sprinkler/Fire Protection", "Fleet Safety", "Cyber Hygiene"],
        "strengths": ["Field surveys", "Recommendation tracking", "Loss prevention"],
        "blurb": "turns site visits into measurable loss-cost reduction the underwriter can credit",
    },
}

FIRST_NAMES = ["Ada", "Marcus", "Priya", "Sienna", "Diego", "Noor", "Theo", "Rumi", "Jules", "Imani"]
LAST_NAMES = [
    "Calderon", "Whitfield", "Okafor", "Brennan", "Vasquez", "Lindqvist",
    "Hayashi", "Kowalski", "Emerson", "Bellamy",
]
REGIONS = ["Northeast", "Mid-Atlantic", "Gulf Coast", "Pacific NW", "Mountain West", "Great Lakes"]

FLOW_STEPS = [
    {"key": "intake", "label": "Client Intake", "actor": "Agent", "icon": "user-round",
     "desc": "Capture risk details, prior loss history and coverage needs from the insured."},
    {"key": "submission", "label": "Submission", "actor": "Broker", "icon": "briefcase",
     "desc": "Package the risk and shop it to carriers whose appetite fits."},
    {"key": "triage", "label": "UW Triage", "actor": "Underwriter", "icon": "file-search",
     "desc": "Clearance, appetite check, request missing schedules and loss runs."},
    {"key": "pricing", "label": "Pricing & Modeling", "actor": "Pricing Actuary", "icon": "calculator",
     "desc": "Apply rating plan, cat load, schedule credits/debits and reinsurance ceding."},
    {"key": "decision", "label": "Bind Decision", "actor": "Underwriter", "icon": "shield-check",
     "desc": "Issue quote, decline, or counter with conditions and subjectivities."},
    {"key": "bind", "label": "Bind & Issue", "actor": "Agent / Broker", "icon": "handshake",
     "desc": "Collect signed application, payment, and issue the policy."},
]

MODULE_TABS = [
    {"key": "Business Owner", "icon": "briefcase"},
    {"key": "AI Engineer", "icon": "sparkles"},
    {"key": "Quotes", "icon": "clipboard-list"},
    {"key": "Policy", "icon": "file-text"},
    {"key": "Claims", "icon": "triangle-alert"},
    {"key": "Actuarial", "icon": "trending-up"},
]

MODULE_DESCRIPTIONS = {
    "AI Engineer": "Build, tune and deploy agentic models.",
    "Quotes": "Run the full intake-to-bind quote workflow.",
    "Policy": "Endorsements, renewals and policy servicing.",
    "Claims": "FNOL, coverage analysis, reserves and subrogation.",
    "Actuarial": "Loss reserving, rate indications, cat modeling.",
}

LOSS_TYPES = [
    "Auto Collision", "Auto Theft", "Property Fire", "Property Water",
    "Property Wind/Hail", "Bodily Injury", "General Liability", "Workers' Comp",
]

VEHICLE_MAKES = ["Toyota", "Honda", "Ford", "Chevrolet", "Tesla", "BMW", "Subaru", "Hyundai"]
VEHICLE_YEARS = [str(y) for y in range(2026, 2010, -1)]
LIABILITY_LIMITS = ["25/50/25", "50/100/50", "100/300/100", "250/500/250"]
DEDUCTIBLES = [250, 500, 1000, 2500]
COVERAGE_LEVELS = ["State Minimum", "Standard", "Full Coverage", "Premium"]
DRIVER_AGE_BANDS = ["16-20", "21-24", "25-64", "65+"]
MILEAGE_BANDS = [
    "Under 7,500 mi/yr", "7,500 – 15,000 mi/yr", "15,000 – 25,000 mi/yr", "Over 25,000 mi/yr",
]
USAGE_OPTIONS = ["Pleasure", "Commute", "Business"]
LINES_OF_BUSINESS = ["Auto", "Commercial Property", "General Liability", "Workers' Comp"]
REQUEST_TYPES = ["Endorsement", "Renewal", "Cancellation", "Reinstatement"]

WORKFLOW_PATCHES = [
    "fast-track-small-claims", "pause-new-bind", "auto-deny-fraud-flag",
    "telematics-discount", "cat-event-surge-handling",
]

AGENT_TOOL_NAMES = [
    "setModuleEnabled", "setPremiumMultiplier", "setDefaultCoverageLevel",
    "setDefaultAutonomy", "setModuleDirective", "addPricingRule",
    "applyWorkflowPatch", "modifyCode (lovable.dev API)",
    "fetchHazardData (NOAA · FEMA · USGS)",
]
