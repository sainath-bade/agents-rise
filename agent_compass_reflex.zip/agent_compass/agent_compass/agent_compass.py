"""Sentinel Underwriters — AI Recruiter & Quote Flow.

Full-stack Python port (Reflex) of the original TanStack Start / React app.
"""

import reflex as rx

from agent_compass import constants, styles
from agent_compass.components.claims_lifecycle import claims_lifecycle
from agent_compass.components.hazard_panel import hazard_panel
from agent_compass.components.reasoning_stream import reasoning_stream
from agent_compass.state import State


def card(*children, elegant: bool = False, gradient: bool = False, **props) -> rx.Component:
    base = dict(styles.CARD_STYLE_GRADIENT if gradient else (styles.CARD_STYLE_ELEGANT if elegant else styles.CARD_STYLE))
    base.setdefault("background", styles.CARD)
    if "background" in props:
        base["background"] = props.pop("background")
    return rx.box(*children, **base, padding="1.25rem", **props)


def field(label: str, control: rx.Component) -> rx.Component:
    return rx.vstack(rx.text(label, size="1", weight="medium"), control, spacing="1", width="100%", align_items="start")


def directive_banner(module: str) -> rx.Component:
    return rx.cond(
        State.directives.get(module, "") != "",
        rx.box(
            rx.text("Business Owner directive", size="1", weight="bold", color=styles.PRIMARY),
            rx.text(State.directives[module], size="2", padding_top="2px"),
            padding="0.75rem", border_left=f"4px solid {styles.PRIMARY}",
            background="oklch(0.48 0.16 255 / 0.05)", border_radius="0.375rem",
            width="100%", margin_bottom="1rem",
        ),
    )


# ---------------------------------------------------------------------------
# Hero
# ---------------------------------------------------------------------------


def hero() -> rx.Component:
    return rx.box(
        rx.vstack(
            rx.hstack(rx.icon("shield", size=16), rx.text("Sentinel Underwriters · P&C Talent Cloud", size="2", weight="medium"), spacing="2", align="center"),
            rx.heading("Re-imagine Insurance with Smart Execution - Agentic AI", size="8", margin_top="0.75rem"),
            rx.text(
                "Generate a role-ready persona in seconds, then walk them through the full "
                "quote-to-bind workflow — agent, broker, underwriter, pricing and beyond.",
                size="4", max_width="42rem", margin_top="0.5rem",
            ),
            align_items="start", color=styles.PRIMARY_FOREGROUND,
        ),
        background=styles.GRADIENT_HERO, padding="4rem 1.5rem",
        border_bottom=f"1px solid {styles.BORDER}",
    )


# ---------------------------------------------------------------------------
# Recruiter
# ---------------------------------------------------------------------------


def recruiter_section() -> rx.Component:
    role_select = card(
        rx.vstack(
            rx.hstack(rx.icon("wand-sparkles", size=18, color=styles.PRIMARY), rx.heading("Recruit a new agent", size="4"), spacing="2", align="center"),
            rx.text("Pick the role and let the AI scout someone who fits.", size="2", color=styles.MUTED_FOREGROUND),
            field("Role to fill", rx.select(list(constants.ROLE_DATA.keys()), value=State.role, on_change=State.set_role, width="100%")),
            rx.button(rx.icon("sparkles", size=16), " Generate persona", width="100%", on_click=State.generate_persona, box_shadow=styles.SHADOW_ELEGANT),
            reasoning_stream(
                "Recruiter agent · live reasoning",
                State.recruit_reasoning_rendered, State.recruit_reasoning_current, State.recruit_reasoning_done,
            ),
            spacing="4", width="100%", align_items="start",
        ),
    )

    persona_card = card(
        rx.vstack(
            rx.hstack(
                rx.vstack(
                    rx.heading(State.persona.name, size="6"),
                    rx.text(State.persona.tagline, size="2", color=styles.MUTED_FOREGROUND),
                    spacing="1", align_items="start",
                ),
                rx.spacer(),
                rx.box(
                    rx.icon("user-round", size=26, color=styles.PRIMARY_FOREGROUND),
                    width="3.5rem", height="3.5rem", border_radius="9999px",
                    background=styles.GRADIENT_HERO, display="flex", align_items="center", justify_content="center",
                ),
                width="100%",
            ),
            rx.text(State.persona.summary, size="2", line_height="1.6"),
            rx.divider(),
            rx.grid(
                rx.vstack(
                    rx.text("Specialties", size="1", weight="bold", color=styles.MUTED_FOREGROUND),
                    rx.hstack(rx.foreach(State.persona.specialties, lambda s: rx.badge(s, variant="soft")), wrap="wrap", spacing="1"),
                    spacing="2", align_items="start",
                ),
                rx.vstack(
                    rx.text("Why selected", size="1", weight="bold", color=styles.MUTED_FOREGROUND),
                    rx.foreach(
                        State.persona.strengths,
                        lambda s: rx.hstack(rx.icon("circle-check-big", size=14, color=styles.PRIMARY), rx.text(s, size="2"), spacing="1", align="center"),
                    ),
                    spacing="2", align_items="start",
                ),
                columns="2", spacing="4", width="100%",
            ),
            spacing="4", width="100%", align_items="start",
        ),
        gradient=True,
    )

    return rx.grid(role_select, persona_card, columns=rx.breakpoints(initial="1", md="2"), spacing="6", width="100%")


# ---------------------------------------------------------------------------
# Module tabs
# ---------------------------------------------------------------------------


def module_tabs() -> rx.Component:
    buttons = []
    for m in constants.MODULE_TABS:
        key = m["key"]
        is_gated = key != "Business Owner"
        active = State.module == key
        disabled = (State.enabled_modules[key] == False) if is_gated else False  # noqa: E712
        buttons.append(
            rx.button(
                rx.icon(m["icon"], size=18),
                rx.text(key, weight="bold"),
                variant=rx.cond(active, "solid", "outline"),
                size="3",
                disabled=disabled if is_gated else False,
                on_click=State.set_module(key),
            )
        )
    return rx.hstack(
        rx.hstack(rx.icon("building-2", size=18, color=styles.PRIMARY), rx.heading("P&C Operations", size="6"), spacing="2", align="center"),
        rx.spacer(),
        rx.hstack(*buttons, wrap="wrap", spacing="2"),
        width="100%", wrap="wrap", align="center", margin_bottom="1.5rem",
    )


# ---------------------------------------------------------------------------
# Chat bubble (shared by Business Owner + AI Engineer panels)
# ---------------------------------------------------------------------------


def _tool_pill(tc: rx.Var) -> rx.Component:
    return rx.hstack(
        rx.icon("wrench", size=12, color=styles.PRIMARY),
        rx.text(tc.tool, font_family="monospace", size="1"),
        rx.cond(
            tc.done,
            rx.text("→ ", tc.message, size="1", color=styles.MUTED_FOREGROUND),
            rx.spinner(size="1"),
        ),
        padding="0.25rem 0.5rem", border_radius="0.25rem",
        background="oklch(0.96 0.02 250 / 0.5)", border=f"1px solid {styles.BORDER}",
        spacing="1", align="center",
    )


def _chat_message(m: rx.Var, user_label: str) -> rx.Component:
    return rx.vstack(
        rx.text(rx.cond(m.role == "user", user_label, "Agent"), size="1", weight="bold", color=styles.MUTED_FOREGROUND, text_transform="uppercase"),
        rx.cond(m.text != "", rx.text(m.text, white_space="pre-wrap", size="2")),
        rx.foreach(m.tool_calls, _tool_pill),
        spacing="1", width="100%", align_items="start",
    )


def _chat_panel(
    messages: rx.Var, input_value: rx.Var, busy: rx.Var, error: rx.Var,
    on_input, on_send, user_label: str, placeholder: str, empty_hint: str,
) -> rx.Component:
    return rx.vstack(
        rx.box(
            rx.cond(messages.length() == 0, rx.text(empty_hint, size="1", color=styles.MUTED_FOREGROUND)),
            rx.foreach(messages, lambda m: _chat_message(m, user_label)),
            rx.cond(busy, rx.hstack(rx.spinner(size="1"), rx.text("Working…", size="1", color=styles.MUTED_FOREGROUND), spacing="1")),
            rx.cond(error != "", rx.text("Error: ", error, size="1", color=styles.DESTRUCTIVE)),
            height="320px", overflow_y="auto", padding="0.75rem",
            border=f"1px solid {styles.BORDER}", border_radius="0.375rem",
            background=styles.BACKGROUND, width="100%",
            display="flex", flex_direction="column", gap="0.75rem",
        ),
        rx.hstack(
            rx.input(value=input_value, on_change=on_input, placeholder=placeholder, max_length=500, width="100%"),
            rx.button(rx.icon("send", size=16), on_click=on_send, disabled=busy | (input_value.length() == 0)),
            width="100%",
        ),
        spacing="3", width="100%",
    )


# ---------------------------------------------------------------------------
# Business Owner panel
# ---------------------------------------------------------------------------


def business_owner_panel() -> rx.Component:
    controls = card(
        rx.vstack(
            rx.hstack(rx.icon("briefcase", size=18, color=styles.PRIMARY), rx.heading("Business Owner control panel", size="4"), spacing="2", align="center"),
            rx.text("Toggle which functions are enabled for the team.", size="2", color=styles.MUTED_FOREGROUND),
            *[
                rx.hstack(
                    rx.vstack(
                        rx.text(k, size="2", weight="bold"),
                        rx.text(constants.MODULE_DESCRIPTIONS[k], size="1", color=styles.MUTED_FOREGROUND),
                        spacing="0", align_items="start",
                    ),
                    rx.spacer(),
                    rx.switch(checked=State.enabled_modules[k], on_change=lambda v, k=k: State.set_module_enabled(k, v)),
                    width="100%", padding="0.6rem", border=f"1px solid {styles.BORDER}", border_radius="0.375rem", align="center",
                )
                for k in constants.MODULE_DESCRIPTIONS.keys()
            ],
            rx.divider(),
            rx.box(
                rx.text("Active configuration", size="1", weight="bold", color=styles.MUTED_FOREGROUND),
                rx.text("Premium multiplier: ", rx.text.span(f"{State.premium_multiplier:.2f}×", weight="bold")),
                rx.text("Default coverage: ", rx.text.span(rx.cond(State.default_coverage != "", State.default_coverage, "—"), weight="bold")),
                rx.text("Default autonomy: ", rx.text.span(rx.cond(State.default_autonomy != "", State.default_autonomy, "—"), weight="bold")),
                padding="0.6rem", border=f"1px solid {styles.BORDER}", border_radius="0.375rem",
                background="oklch(0.96 0.02 250 / 0.4)", width="100%", font_size="0.78rem",
            ),
            spacing="3", width="100%", align_items="start",
        ),
    )

    chat = card(
        rx.vstack(
            rx.hstack(rx.icon("message-square", size=18, color=styles.PRIMARY), rx.heading("Brief the AI Engineer", size="4"), spacing="2", align="center"),
            rx.text("Tell the AI Engineer what to change. They'll reconfigure Quotes, Policy, Claims and Actuarial.", size="2", color=styles.MUTED_FOREGROUND),
            rx.hstack(
                rx.badge("FULL AUTHORITY granted", size="1"),
                rx.badge("NOAA · FEMA · USGS data", variant="soft", size="1"),
                rx.badge("Live code edits", variant="soft", size="1"),
                spacing="1", wrap="wrap",
            ),
            _chat_panel(
                State.owner_messages, State.owner_input, State.owner_busy, State.owner_error,
                State.set_owner_input, State.send_owner_message, "Business Owner",
                "Instruct the AI Engineer…",
                'Agentic workflow: every instruction is planned, executed with tools, then reported. '
                'Try "Hard market — surcharge 12%, tighten Quotes & Claims, flag fraud".',
            ),
            spacing="3", width="100%", align_items="start",
        ),
        elegant=True,
    )

    return rx.grid(controls, chat, columns=rx.breakpoints(initial="1", lg="2"), spacing="6", width="100%")


# ---------------------------------------------------------------------------
# AI Engineer panel
# ---------------------------------------------------------------------------


def ai_engineer_panel() -> rx.Component:
    console = card(
        rx.vstack(
            rx.hstack(rx.icon("wrench", size=18, color=styles.PRIMARY), rx.heading("AI Engineer console", size="4"), spacing="2", align="center"),
            rx.text("Use AI tools to directly reconfigure Quotes, Policy, Claims and Actuarial.", size="2", color=styles.MUTED_FOREGROUND),
            rx.hstack(rx.badge("FULL AUTHORITY granted", size="1"), rx.badge("Hazard intel: NOAA · FEMA · USGS", variant="soft", size="1"), spacing="1", wrap="wrap"),
            rx.hstack(*[rx.badge(t, variant="soft", font_family="monospace", size="1") for t in constants.AGENT_TOOL_NAMES], wrap="wrap", spacing="1"),
            _chat_panel(
                State.engineer_messages, State.engineer_input, State.engineer_busy, State.engineer_error,
                State.set_engineer_input, State.send_engineer_message, "AI Engineer (you)",
                "Run a tool, e.g. 'Disable Actuarial and add 5% surcharge'…",
                'Try "Surcharge Quotes by 8% — wildfire season" or "Default new auto quotes to Self-Driving + Premium".',
            ),
            spacing="3", width="100%", align_items="start",
        ),
        elegant=True,
    )

    feed = card(
        rx.vstack(
            rx.hstack(rx.icon("sparkles", size=18, color=styles.PRIMARY), rx.heading("Realtime authority feed", size="4"), spacing="2", align="center"),
            rx.text("Every config change, pricing rule, workflow patch and code modification staged in real time.", size="2", color=styles.MUTED_FOREGROUND),
            rx.cond(
                State.code_patches.length() > 0,
                rx.vstack(
                    rx.text("Code patches", size="1", weight="bold", color=styles.MUTED_FOREGROUND),
                    rx.foreach(
                        State.code_patches,
                        lambda p: rx.box(
                            rx.hstack(rx.text(p.file, font_family="monospace", color=styles.PRIMARY, size="1"), rx.spacer(), rx.badge(p.module, size="1"), width="100%"),
                            rx.text(p.summary, size="1", padding_top="2px"),
                            rx.code_block(p.diff, language="diff", font_size="0.65rem", max_height="10rem", width="100%"),
                            padding="0.5rem", border=f"1px solid {styles.BORDER}", border_radius="0.375rem", width="100%",
                        ),
                    ),
                    spacing="2", width="100%", align_items="start",
                ),
            ),
            rx.cond(
                State.custom_rules.length() > 0,
                rx.vstack(
                    rx.text("Custom pricing rules (live)", size="1", weight="bold", color=styles.MUTED_FOREGROUND),
                    rx.foreach(
                        State.custom_rules,
                        lambda r: rx.hstack(
                            rx.icon("calculator", size=14, color=styles.PRIMARY),
                            rx.vstack(
                                rx.text(r.name, " ", rx.cond(r.adjustment >= 0, "+", ""), (r.adjustment * 100).to(str), "%", " · ", r.line, size="1", weight="bold"),
                                rx.text(r.reason, size="1", color=styles.MUTED_FOREGROUND),
                                spacing="0", align_items="start",
                            ),
                            padding="0.4rem", border=f"1px solid {styles.BORDER}", border_radius="0.375rem", width="100%",
                        ),
                    ),
                    spacing="2", width="100%", align_items="start",
                ),
            ),
            rx.cond(
                State.workflow_patches.length() > 0,
                rx.vstack(
                    rx.text("Workflow patches deployed", size="1", weight="bold", color=styles.MUTED_FOREGROUND),
                    rx.foreach(
                        State.workflow_patches,
                        lambda w: rx.box(
                            rx.text(w.patch, font_family="monospace", color=styles.PRIMARY, size="1"),
                            rx.text(w.module, " · ", w.note, size="1", color=styles.MUTED_FOREGROUND),
                            padding="0.4rem", border=f"1px solid {styles.BORDER}", border_radius="0.375rem", width="100%",
                        ),
                    ),
                    spacing="2", width="100%", align_items="start",
                ),
            ),
            rx.cond(
                (State.ai_change_log.length() == 0) & (State.code_patches.length() == 0),
                rx.text(
                    "No changes yet. Brief the AI Engineer — they have full authority to "
                    "reconfigure modules, author pricing rules and stage code patches in real time.",
                    size="2", color=styles.MUTED_FOREGROUND,
                ),
                rx.vstack(
                    rx.text("Activity log", size="1", weight="bold", color=styles.MUTED_FOREGROUND),
                    rx.foreach(
                        State.ai_change_log,
                        lambda entry: rx.hstack(
                            rx.icon("circle-check-big", size=14, color=styles.PRIMARY),
                            rx.text(entry, size="2"),
                            padding="0.4rem", border_radius="0.375rem",
                            background="oklch(0.96 0.02 250 / 0.4)", spacing="1",
                        ),
                    ),
                    spacing="2", width="100%", align_items="start",
                ),
            ),
            spacing="3", width="100%", align_items="start",
        ),
    )

    return rx.grid(console, feed, columns=rx.breakpoints(initial="1", lg="2"), spacing="6", width="100%")


# ---------------------------------------------------------------------------
# Quotes module
# ---------------------------------------------------------------------------


def _stepper() -> rx.Component:
    items = []
    for i, step in enumerate(constants.FLOW_STEPS):
        is_active = State.active_step == step["key"]
        items.append(
            rx.box(
                rx.hstack(
                    rx.box(
                        rx.icon(step["icon"], size=16),
                        width="2rem", height="2rem", border_radius="0.375rem",
                        display="flex", align_items="center", justify_content="center",
                        background=rx.cond(is_active, styles.GRADIENT_HERO, "oklch(0.96 0.02 250)"),
                        color=rx.cond(is_active, styles.PRIMARY_FOREGROUND, styles.SECONDARY_FOREGROUND),
                    ),
                    rx.text(f"Step {i + 1}", size="1", weight="bold", color=styles.MUTED_FOREGROUND),
                    spacing="2", align="center",
                ),
                rx.text(step["label"], weight="bold", size="2", padding_top="0.6rem"),
                rx.text(step["actor"], size="1", color=styles.MUTED_FOREGROUND),
                padding="1rem", border_radius="0.5rem", cursor="pointer",
                border=rx.cond(is_active, f"1px solid {styles.PRIMARY}", f"1px solid {styles.BORDER}"),
                box_shadow=rx.cond(is_active, styles.SHADOW_ELEGANT, styles.SHADOW_SOFT),
                background=styles.CARD,
                on_click=State.set_active_step(step["key"]),
            )
        )
    return rx.grid(*items, columns=rx.breakpoints(initial="2", md="6"), spacing="3", width="100%")


def _auto_fields() -> rx.Component:
    return rx.cond(
        State.is_auto,
        rx.box(
            rx.text("Vehicle details", size="1", weight="bold", color=styles.MUTED_FOREGROUND, margin_bottom="0.5rem"),
            rx.grid(
                field("Year", rx.select(constants.VEHICLE_YEARS, value=State.vehicle_year.to(str), on_change=State.set_vehicle_year, width="100%")),
                field("Make", rx.select(constants.VEHICLE_MAKES, value=State.vehicle_make, on_change=State.set_vehicle_make, width="100%")),
                field("Model", rx.input(value=State.vehicle_model, on_change=State.set_vehicle_model, max_length=40)),
                rx.box(field("VIN", rx.input(value=State.vin, on_change=State.set_vin, max_length=17, font_family="monospace")), grid_column="span 2"),
                rx.vstack(
                    rx.text("Vehicle Autonomy", size="1", weight="medium"),
                    rx.hstack(
                        *[
                            rx.button(
                                opt, size="1",
                                variant=rx.cond(State.autonomy == opt, "solid", "outline"),
                                on_click=State.set_autonomy(opt),
                            )
                            for opt in ["Human-Driven", "Self-Driving"]
                        ],
                        spacing="2",
                    ),
                    spacing="1", align_items="start", grid_column="span 3",
                ),
                rx.vstack(
                    rx.text("Primary Driver Age", size="1", weight="medium"),
                    rx.hstack(
                        *[
                            rx.button(
                                band, size="1",
                                variant=rx.cond(State.driver_age_band == band, "solid", "outline"),
                                disabled=State.autonomy == "Self-Driving",
                                on_click=State.set_driver_age_band(band),
                            )
                            for band in constants.DRIVER_AGE_BANDS
                        ],
                        spacing="2", wrap="wrap",
                    ),
                    spacing="1", align_items="start", grid_column="span 3",
                ),
                field("Annual Mileage", rx.select(constants.MILEAGE_BANDS, value=State.mileage_band, on_change=State.set_mileage_band, width="100%")),
                field("Primary Usage", rx.select(constants.USAGE_OPTIONS, value=State.usage, on_change=State.set_usage, width="100%")),
                field("Prior Losses (5 yr)", rx.input(value=State.prior_losses.to(str), on_change=State.set_prior_losses, type="number")),
                columns="3", spacing="3", width="100%",
            ),
            padding="1rem", border=f"1px solid {styles.BORDER}", border_radius="0.5rem",
            background="oklch(0.96 0.02 250 / 0.4)", width="100%", margin_top="0.75rem",
        ),
    )


def quotes_module() -> rx.Component:
    detail_card = card(
        rx.vstack(
            rx.hstack(rx.icon("clipboard-list", size=18, color=styles.PRIMARY), rx.heading(rx.cond(True, "Quote step", "")), spacing="2", align="center"),
            rx.grid(
                field("Line of Business", rx.select(constants.LINES_OF_BUSINESS, value=State.quote_line, on_change=State.set_quote_line, width="100%")),
                field("Insured Name", rx.input(value=State.insured_name, on_change=State.set_insured_name, max_length=100)),
                rx.box(field("Address", rx.input(value=State.address, on_change=State.set_address, max_length=200, placeholder="Street, City, State ZIP")), grid_column="span 2"),
                field("Insured Entity", rx.select(["Vehicle", "Property", "Business"], value=State.insured_entity, on_change=State.set_insured_entity, width="100%")),
                field(
                    rx.cond(State.is_auto, "Vehicle Value ($)", "Total Insured Value ($)").to(str),
                    rx.input(value=State.tiv.to(str), on_change=State.set_tiv, type="number"),
                ),
                columns="2", spacing="3", width="100%",
            ),
            _auto_fields(),
            rx.cond(
                ~State.is_auto,
                field("Prior Losses (5 yr)", rx.input(value=State.prior_losses.to(str), on_change=State.set_prior_losses, type="number")),
            ),
            rx.cond(
                State.is_auto,
                rx.box(
                    rx.text("Coverage details", size="1", weight="bold", color=styles.MUTED_FOREGROUND, margin_bottom="0.5rem"),
                    rx.grid(
                        field("Coverage Level", rx.select(constants.COVERAGE_LEVELS, value=State.coverage_level, on_change=State.set_coverage_level, width="100%")),
                        field("BI / PD Limits", rx.select(constants.LIABILITY_LIMITS, value=State.liability_limit, on_change=State.set_liability_limit, width="100%")),
                        field("Deductible ($)", rx.select([str(d) for d in constants.DEDUCTIBLES], value=State.deductible.to(str), on_change=State.set_deductible, width="100%")),
                        columns="3", spacing="3", width="100%",
                    ),
                    field("Loss History Notes", rx.input(value=State.loss_history, on_change=State.set_loss_history, max_length=300)),
                    border_top=f"1px solid {styles.BORDER}", padding_top="1rem", margin_top="1rem", width="100%",
                    display="flex", flex_direction="column", gap="0.75rem",
                ),
            ),
            rx.hstack(
                rx.spacer(),
                rx.button("Back", variant="outline", disabled=State.active_index == 0, on_click=State.step_back),
                rx.button(
                    rx.icon("send", size=14), " ",
                    rx.cond(State.quote_submitted, "Re-submit intake", "Submit intake"),
                    variant="soft", on_click=State.submit_intake,
                ),
                rx.button(rx.icon("send", size=14), " Advance to next desk", disabled=State.active_index == len(constants.FLOW_STEPS) - 1, on_click=State.step_forward),
                spacing="2", width="100%",
            ),
            rx.cond(
                (State.active_step == "intake") & State.quote_submitted,
                reasoning_stream(
                    "Underwriter thought process",
                    State.intake_reasoning_rendered, State.intake_reasoning_current, State.intake_reasoning_done,
                ),
            ),
            spacing="4", width="100%", align_items="start",
        ),
    )

    pricing_card = card(
        rx.vstack(
            rx.hstack(rx.icon("calculator", size=18, color=styles.PRIMARY), rx.heading("Pricing Indication", size="4"), spacing="2", align="center"),
            rx.text("Live rate calc — ", State.insured_name, size="2", color=styles.MUTED_FOREGROUND),
            rx.vstack(
                rx.text("Indicated Premium", size="1", weight="bold", color=styles.MUTED_FOREGROUND, text_transform="uppercase"),
                rx.cond(
                    ~State.quote_submitted,
                    rx.text("Complete the intake form and click Submit intake to run the quote workflow.", size="2", color=styles.MUTED_FOREGROUND),
                    rx.cond(
                        State.reasoning_done,
                        rx.heading("$", State.indication.premium, size="8"),
                        rx.hstack(rx.spinner(), rx.text("Agent is reviewing intake…", size="2", color=styles.MUTED_FOREGROUND), spacing="2"),
                    ),
                ),
                spacing="1", align_items="start", width="100%",
            ),
            rx.divider(),
            rx.grid(
                rx.vstack(rx.text("Base rate", size="1", color=styles.MUTED_FOREGROUND), rx.text(rx.cond(State.quote_submitted & State.reasoning_done, (State.indication.base_rate * 1000).to(str), "—"), weight="medium"), spacing="0"),
                rx.vstack(rx.text("Projected LR", size="1", color=styles.MUTED_FOREGROUND), rx.text(rx.cond(State.quote_submitted & State.reasoning_done, State.indication.loss_ratio.to(str) + "%", "—"), weight="medium"), spacing="0"),
                rx.vstack(rx.text("Underwriter", size="1", color=styles.MUTED_FOREGROUND), rx.text(rx.cond(State.persona.role == "Underwriter", State.persona.name, "Auto-routed"), weight="medium"), spacing="0"),
                rx.vstack(
                    rx.text("Status", size="1", color=styles.MUTED_FOREGROUND),
                    rx.cond(
                        ~State.quote_submitted, rx.badge("Awaiting submission", variant="soft"),
                        rx.cond(
                            State.reasoning_done,
                            rx.cond(State.indication.loss_ratio < 65, rx.badge("Quote ready"), rx.badge("Refer to UW", color_scheme="amber")),
                            rx.badge("Pending", variant="soft"),
                        ),
                    ),
                    spacing="0",
                ),
                columns="2", spacing="4", width="100%",
            ),
            spacing="4", width="100%", align_items="start",
        ),
        gradient=True,
    )

    return rx.vstack(
        directive_banner("Quotes"),
        rx.cond(
            State.premium_multiplier != 1,
            rx.box(
                rx.text("Global premium multiplier ", rx.text.span(f"{State.premium_multiplier:.2f}×", weight="bold"), " is active", rx.cond(State.premium_reason != "", " — " + State.premium_reason, "")),
                padding="0.6rem", border=f"1px solid {styles.BORDER}", border_radius="0.375rem",
                background="oklch(0.96 0.02 250 / 0.4)", font_size="0.78rem", color=styles.MUTED_FOREGROUND, width="100%",
            ),
        ),
        _stepper(),
        rx.grid(detail_card, pricing_card, columns=rx.breakpoints(initial="1", md="2"), spacing="6", width="100%", margin_top="1.5rem"),
        rx.cond(State.quote_submitted, hazard_panel("hazard_uw", State.address, "underwriting", State.fetch_uw_hazard)),
        spacing="4", width="100%", align_items="start",
    )


# ---------------------------------------------------------------------------
# Policy module
# ---------------------------------------------------------------------------


def policy_module() -> rx.Component:
    return card(
        rx.vstack(
            rx.hstack(rx.icon("file-text", size=18, color=styles.PRIMARY), rx.heading("Policy servicing intake", size="4"), spacing="2", align="center"),
            rx.text("Endorsements, renewals and cancellations.", size="2", color=styles.MUTED_FOREGROUND),
            directive_banner("Policy"),
            rx.grid(
                field("Policy Number", rx.input(value=State.policy_number, on_change=State.set_policy_number)),
                field("Insured Name", rx.input(value=State.policy_insured_name, on_change=State.set_policy_insured_name)),
                field("Request Type", rx.select(constants.REQUEST_TYPES, value=State.policy_request_type, on_change=State.set_policy_request_type, width="100%")),
                field("Effective Date", rx.input(value=State.policy_effective_date, on_change=State.set_policy_effective_date, type="date")),
                rx.box(field("Notes", rx.input(value=State.policy_notes, on_change=State.set_policy_notes)), grid_column="span 2"),
                columns="2", spacing="3", width="100%",
            ),
            rx.button(rx.icon("send", size=16), " Submit policy request", width="100%", on_click=State.submit_policy_request),
            rx.cond(
                State.policy_submitted,
                rx.box(
                    rx.text("Request queued", weight="bold"),
                    rx.text(State.policy_submitted_summary, size="2", color=styles.MUTED_FOREGROUND, padding_top="2px"),
                    padding="0.75rem", border=f"1px solid {styles.BORDER}", border_radius="0.375rem",
                    background="oklch(0.96 0.02 250 / 0.3)", width="100%",
                ),
            ),
            spacing="4", width="100%", align_items="start",
        ),
    )


# ---------------------------------------------------------------------------
# Claims module
# ---------------------------------------------------------------------------


def _attachment_row(a: rx.Var, i: int) -> rx.Component:
    return rx.hstack(
        rx.text(a.name, " (", (a.size / 1024).to(str), " KB)", size="2", overflow="hidden", text_overflow="ellipsis"),
        rx.spacer(),
        rx.button("remove", size="1", variant="ghost", color_scheme="red", on_click=State.remove_attachment(i)),
        width="100%", padding="0.4rem", border=f"1px solid {styles.BORDER}", border_radius="0.375rem", background=styles.CARD,
    )


def claims_module() -> rx.Component:
    fnol_card = card(
        rx.vstack(
            rx.hstack(rx.icon("triangle-alert", size=18, color=styles.PRIMARY), rx.heading("First Notice of Loss (FNOL) Intake", size="4"), spacing="2", align="center"),
            rx.text("Capture the claim details, attach evidence, then run AI adjudication.", size="2", color=styles.MUTED_FOREGROUND),
            rx.grid(
                field("Claimant Name", rx.input(value=State.claim_claimant_name, on_change=State.set_claim_claimant_name)),
                field("Policy Number", rx.input(value=State.claim_policy_number, on_change=State.set_claim_policy_number)),
                field("Loss Type", rx.select(constants.LOSS_TYPES, value=State.claim_loss_type, on_change=State.set_claim_loss_type, width="100%")),
                field("Date of Loss", rx.input(value=State.claim_date_of_loss, on_change=State.set_claim_date_of_loss, type="date")),
                rx.box(field("Location of Loss", rx.input(value=State.claim_location, on_change=State.set_claim_location)), grid_column="span 2"),
                field("Estimated Amount ($)", rx.input(value=State.claim_estimated_amount.to(str), on_change=State.set_claim_estimated_amount, type="number")),
                field("Injuries", rx.input(value=State.claim_injuries, on_change=State.set_claim_injuries)),
                field("Police Report #", rx.input(value=State.claim_police_report, on_change=State.set_claim_police_report)),
                field("Third Party Involvement", rx.input(value=State.claim_third_party, on_change=State.set_claim_third_party)),
                columns="2", spacing="3", width="100%",
            ),
            rx.divider(),
            rx.vstack(
                rx.text("Evidence — photos, scene videos, recorded statements", size="1", weight="medium"),
                rx.upload(
                    rx.vstack(
                        rx.icon("upload", size=20, color=styles.MUTED_FOREGROUND),
                        rx.text("Drag & drop or click to select files", size="1", color=styles.MUTED_FOREGROUND),
                        align="center", spacing="1",
                    ),
                    id="claim_upload", multiple=True, accept={"image/*": [], "video/*": [], "audio/*": []},
                    border=f"1px dashed {styles.BORDER}", padding="1rem", border_radius="0.375rem", width="100%",
                    on_drop=State.handle_claim_upload(rx.upload_files(upload_id="claim_upload")),
                ),
                rx.text("Up to 12 MB per file. Images are sent to the AI adjuster as multimodal input.", size="1", color=styles.MUTED_FOREGROUND),
                rx.cond(
                    State.claim_attachments.length() > 0,
                    rx.vstack(rx.foreach(State.claim_attachments, _attachment_row), spacing="1", width="100%"),
                ),
                spacing="2", width="100%", align_items="start",
            ),
            rx.divider(),
            rx.vstack(
                rx.hstack(
                    rx.text("Loss Description", size="1", weight="medium"),
                    rx.spacer(),
                    rx.button(
                        rx.cond(State.describing_evidence, rx.spinner(size="1"), rx.icon("sparkles", size=14)),
                        rx.cond(State.describing_evidence, " Analyzing evidence…", " Auto-fill from evidence"),
                        size="1", variant="outline",
                        disabled=State.describing_evidence | (State.claim_attachments.length() == 0),
                        on_click=State.run_describe_evidence,
                    ),
                    width="100%", align="center",
                ),
                rx.text_area(value=State.claim_description, on_change=State.set_claim_description, min_height="7rem", width="100%"),
                rx.cond(State.describe_error != "", rx.text(State.describe_error, size="1", color=styles.DESTRUCTIVE)),
                spacing="2", width="100%", align_items="start",
            ),
            rx.button(
                rx.cond(State.adjudicating, rx.spinner(size="2"), rx.icon("sparkles", size=16)),
                rx.cond(State.adjudicating, " Adjudicating with AI…", " Run AI Adjudication"),
                width="100%", disabled=State.adjudicating, on_click=State.run_adjudication,
            ),
            spacing="4", width="100%", align_items="start",
        ),
    )

    recommendation_card = card(
        rx.vstack(
            rx.hstack(rx.icon("file-search", size=18, color=styles.PRIMARY), rx.heading("Adjuster Recommendation", size="4"), spacing="2", align="center"),
            rx.text("AI claims analyst reviews the FNOL plus all attached evidence.", size="2", color=styles.MUTED_FOREGROUND),
            rx.cond(
                (State.adjudication == "") & (~State.adjudicating) & (State.adjudication_error == ""),
                rx.text("Fill the form, attach evidence, then click Run AI Adjudication.", size="2", color=styles.MUTED_FOREGROUND),
            ),
            rx.cond(
                State.adjudicating,
                rx.hstack(rx.spinner(size="2"), rx.text("Reviewing ", State.claim_attachments.length(), " attachment(s) and FNOL…", size="2", color=styles.MUTED_FOREGROUND), spacing="2"),
            ),
            rx.cond(
                State.adjudication_error != "",
                rx.box(rx.text(State.adjudication_error, size="2", color=styles.DESTRUCTIVE), padding="0.75rem", border=f"1px solid {styles.DESTRUCTIVE}", border_radius="0.375rem", width="100%"),
            ),
            rx.cond(
                State.adjudication != "",
                rx.box(rx.markdown(State.adjudication), padding="0.75rem", border=f"1px solid {styles.BORDER}", border_radius="0.375rem", background="oklch(0.96 0.02 250 / 0.3)", width="100%"),
            ),
            spacing="3", width="100%", align_items="start",
        ),
    )

    return rx.vstack(
        directive_banner("Claims"),
        rx.grid(fnol_card, recommendation_card, columns=rx.breakpoints(initial="1", md="2"), spacing="6", width="100%"),
        hazard_panel("hazard_claims", State.claim_location, "claims", State.fetch_claims_hazard),
        claims_lifecycle(),
        spacing="6", width="100%", align_items="start",
    )


# ---------------------------------------------------------------------------
# Actuarial module
# ---------------------------------------------------------------------------


def actuarial_module() -> rx.Component:
    return card(
        rx.vstack(
            rx.hstack(rx.icon("trending-up", size=18, color=styles.PRIMARY), rx.heading("Actuarial workspace", size="4"), spacing="2", align="center"),
            rx.text("Loss reserving, rate indications, cat modeling and filings.", size="2", color=styles.MUTED_FOREGROUND),
            directive_banner("Actuarial"),
            rx.text("This module is coming soon. Switch back to Quotes to run the full intake-to-bind flow.", size="2", color=styles.MUTED_FOREGROUND),
            spacing="3", width="100%", align_items="start",
        ),
    )


# ---------------------------------------------------------------------------
# Page
# ---------------------------------------------------------------------------


def index() -> rx.Component:
    return rx.box(
        hero(),
        rx.box(
            recruiter_section(),
            rx.box(module_tabs(), margin_top="4rem"),
            rx.match(
                State.module,
                ("Business Owner", business_owner_panel()),
                ("AI Engineer", ai_engineer_panel()),
                ("Quotes", quotes_module()),
                ("Policy", policy_module()),
                ("Claims", claims_module()),
                ("Actuarial", actuarial_module()),
            ),
            rx.box(
                rx.text("Sentinel Underwriters · Demo P&C platform", size="1", color=styles.MUTED_FOREGROUND),
                text_align="center", padding="2rem 0", border_top=f"1px solid {styles.BORDER}", margin_top="3rem", width="100%",
            ),
            max_width="72rem", margin="0 auto", padding="3rem 1.5rem",
        ),
        background=styles.BACKGROUND, min_height="100vh",
    )


app = rx.App(
    theme=rx.theme(accent_color="blue", radius="medium"),
)
app.add_page(index, title="Sentinel Underwriters — AI Recruiter & Quote Flow", route="/")
