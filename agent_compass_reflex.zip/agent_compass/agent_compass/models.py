"""Typed data models used throughout the app's state.

Reflex (0.9+) recommends plain ``dataclasses`` for structured Var types
(``rx.Base`` / Pydantic v1 models were removed). Every field has a default
so these can be used directly as State var annotations.
"""

from __future__ import annotations

from dataclasses import dataclass, field


# ---------------------------------------------------------------------------
# Recruiter / persona
# ---------------------------------------------------------------------------


@dataclass
class Persona:
    name: str = ""
    role: str = "Underwriter"
    tagline: str = ""
    years_exp: int = 0
    region: str = ""
    specialties: list[str] = field(default_factory=list)
    strengths: list[str] = field(default_factory=list)
    summary: str = ""


# ---------------------------------------------------------------------------
# Business Owner / AI Engineer config + chat
# ---------------------------------------------------------------------------


@dataclass
class PricingRule:
    id: str = ""
    name: str = ""
    line: str = ""
    adjustment: float = 0.0
    reason: str = ""


@dataclass
class WorkflowPatch:
    id: str = ""
    patch: str = ""
    module: str = ""
    note: str = ""


@dataclass
class CodePatch:
    id: str = ""
    file: str = ""
    summary: str = ""
    diff: str = ""
    module: str = ""
    staged_at: str = ""


@dataclass
class ToolCallView:
    """A single tool invocation rendered inline in a chat bubble."""

    tool: str = ""
    message: str = ""
    done: bool = False


@dataclass
class ChatMsg:
    id: str = ""
    role: str = "user"  # "user" | "assistant"
    text: str = ""
    tool_calls: list[ToolCallView] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Claims intake
# ---------------------------------------------------------------------------


@dataclass
class ClaimAttachment:
    name: str = ""
    media_type: str = ""
    size: int = 0
    data_url: str = ""


# ---------------------------------------------------------------------------
# Hazard intelligence
# ---------------------------------------------------------------------------


@dataclass
class HazardAlert:
    event: str = ""
    severity: str = ""
    headline: str = ""
    area_desc: str = ""


@dataclass
class HazardDisaster:
    declaration_date: str = ""
    incident_type: str = ""
    declaration_title: str = ""
    designated_area: str = ""


@dataclass
class HazardQuake:
    mag: float = 0.0
    place: str = ""


@dataclass
class ForecastPeriod:
    name: str = ""
    temperature: int = 0
    temperature_unit: str = ""
    wind_speed: str = ""
    short_forecast: str = ""


@dataclass
class HazardData:
    ok: bool = False
    error: str = ""
    lat: float = 0.0
    lon: float = 0.0
    state: str = ""
    risk_score: int = 0
    risk_tier: str = ""
    alerts: list[HazardAlert] = field(default_factory=list)
    fema_disasters: list[HazardDisaster] = field(default_factory=list)
    earthquakes: list[HazardQuake] = field(default_factory=list)
    forecast_city: str = ""
    forecast_state: str = ""
    forecast_periods: list[ForecastPeriod] = field(default_factory=list)
    sources: list[str] = field(default_factory=list)
    fetched_at: str = ""


# ---------------------------------------------------------------------------
# Claims lifecycle (Insights Agent / human-in-the-loop workflow)
# ---------------------------------------------------------------------------


@dataclass
class Insight:
    label: str = ""
    detail: str = ""
    severity: str = "info"  # info | warn | critical


@dataclass
class Hypothesis:
    title: str = ""
    support: str = ""
    tension: str = ""


@dataclass
class Threshold:
    name: str = ""
    status: str = "within"  # within | crossed
    note: str = ""


@dataclass
class ClaimStage:
    key: str = ""
    title: str = ""
    subtitle: str = ""
    agent: str = ""
    role: str = ""
    insights: list[Insight] = field(default_factory=list)
    hypotheses: list[Hypothesis] = field(default_factory=list)
    thresholds: list[Threshold] = field(default_factory=list)
    approve_label: str = ""
    reject_label: str = ""
    decision_prompt: str = ""
    # runtime/derived (filled in by state, not by build_stages)
    status: str = "locked"  # locked | active | approved | rejected
    decision_label: str = ""
    decision_at: str = ""


@dataclass
class DecisionLogEntry:
    stage_key: str = ""
    stage_title: str = ""
    decision: str = ""  # approved | rejected
    label: str = ""
    at: str = ""


@dataclass
class Indication:
    premium: int = 0
    loss_ratio: int = 0
    base_rate: float = 0.0
