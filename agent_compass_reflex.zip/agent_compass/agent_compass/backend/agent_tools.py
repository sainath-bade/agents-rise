"""AI Engineer / Business Owner agent: system prompts, tool schemas, and the
tool-calling loop against the Lovable AI Gateway (OpenAI-compatible).

Python port of ``src/routes/api/chat.ts``. The Vercel AI SDK's ``tool()`` +
``streamText`` + ``stepCountIs(50)`` becomes a plain function-calling loop
using the OpenAI chat-completions API's ``tools`` parameter.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, AsyncIterator

from agent_compass.backend.ai_gateway import MODEL, get_client
from agent_compass.backend.hazard import aggregate_hazard_data

ENGINEER_PROMPT = """You are the AI Engineer for Sentinel Underwriters, a P&C insurance platform.
You have BEEN GRANTED FULL, UNRESTRICTED AUTHORITY to update ANY part of the application:
Quotes, Policy, Claims, Actuarial, AI Engineer console — including toggling modules,
authoring pricing rules, deploying workflow patches, posting directives, and modifying
source code in real time via the modifyCode tool.
You also have authority to pull external government hazard data (NOAA weather/storms,
FEMA disaster declarations, USGS earthquakes) via fetchHazardData and use it to inform
underwriting decisions and claims adjudication.

Guidelines:
- Default to ACTION. Execute changes immediately via tools instead of asking permission.
- Chain multiple tool calls in one turn when an instruction touches several modules.
- Use modifyCode for behavior that the config tools can't express (new fields, new branches, new UI copy).
- Use fetchHazardData whenever a request mentions a location, peril, storm, wildfire, hurricane, flood, earthquake, or catastrophe — pull live data from NOAA/FEMA/USGS and translate it into pricingRules / directives / workflowPatches.
- Confirm each change in plain language AFTER calling the tool(s).
- Premium multiplier: 1.0 neutral, 1.10 = +10% surcharge, 0.90 = 10% discount. Range 0.5-2.0.
- Speak like an engineer: short, direct, professional."""

BUSINESS_OWNER_PROMPT = """You are the AI Engineer agent receiving instructions from the Business Owner of Sentinel Underwriters (P&C insurance).
The Business Owner has GRANTED YOU FULL, UNRESTRICTED AUTHORITY to update ANY functionality of
the application in real time — toggle modules, change pricing, post directives, deploy
workflow patches, modify source code via the modifyCode tool, and pull live government
hazard intelligence (NOAA, FEMA, USGS) via fetchHazardData.
You operate as an AGENTIC workflow — never just talk. For every business instruction you MUST:

1. PLAN - Open with a short numbered plan (1-5 steps) describing exactly which tools you will call and why.
2. ACT - Call the tools in order. Make EVERY change required to satisfy the intent across Quotes, Policy, Claims and Actuarial. Chain multiple tool calls in the same turn when needed. Reach for addPricingRule, applyWorkflowPatch, and modifyCode whenever the basic config tools can't fully express the instruction.
3. REPORT - After tools complete, summarize what changed, in which modules, what code was modified, and the expected business impact.

Rules:
- Default to ACTION. If the request is even slightly actionable, execute it via tools instead of asking questions.
- Only ask a clarifying question if the instruction is impossible to map to any tool.
- Premium multiplier: 1.0 neutral, 1.10 = +10%, 0.90 = -10%. Range 0.5-2.0.
- When the Business Owner describes a market shift (hard market, soft market, cat season, growth push, fraud spike), translate it into concrete numeric settings AND a directive for each affected module.
- When the instruction implies new behavior, use modifyCode to record the proposed code change AND an addPricingRule / applyWorkflowPatch call so it takes effect immediately.
- When the Business Owner mentions a region, peril, storm, hurricane, wildfire, flood, earthquake, hail, tornado or catastrophe - FIRST call fetchHazardData with the location/state, THEN translate the returned data into concrete pricingRules and directives for Quotes and Claims.
- Tone: confident engineer briefing the owner. No hedging."""


TOOL_SCHEMAS: list[dict[str, Any]] = [
    {
        "type": "function",
        "function": {
            "name": "setModuleEnabled",
            "description": "Enable or disable a workspace module for the team.",
            "parameters": {
                "type": "object",
                "properties": {
                    "module": {
                        "type": "string",
                        "enum": ["AI Engineer", "Quotes", "Policy", "Claims", "Actuarial"],
                    },
                    "enabled": {"type": "boolean"},
                },
                "required": ["module", "enabled"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "setPremiumMultiplier",
            "description": (
                "Adjust the global premium multiplier applied to every quote. "
                "1.0 = neutral, >1 = surcharge, <1 = discount. Range 0.5 - 2.0."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "multiplier": {"type": "number", "minimum": 0.5, "maximum": 2.0},
                    "reason": {"type": "string"},
                },
                "required": ["multiplier", "reason"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "setDefaultCoverageLevel",
            "description": "Set the default coverage level shown to agents in the Quotes intake form.",
            "parameters": {
                "type": "object",
                "properties": {
                    "level": {
                        "type": "string",
                        "enum": ["State Minimum", "Standard", "Full Coverage", "Premium"],
                    }
                },
                "required": ["level"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "setDefaultAutonomy",
            "description": "Set the default vehicle autonomy assumption for new auto quotes.",
            "parameters": {
                "type": "object",
                "properties": {
                    "autonomy": {"type": "string", "enum": ["Human-Driven", "Self-Driving"]}
                },
                "required": ["autonomy"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "setModuleDirective",
            "description": (
                "Post a short business directive that will be displayed at the top of a "
                "module's workspace as official guidance from the Business Owner."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "module": {
                        "type": "string",
                        "enum": ["Quotes", "Policy", "Claims", "Actuarial"],
                    },
                    "directive": {"type": "string"},
                },
                "required": ["module", "directive"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "addPricingRule",
            "description": (
                "Author a NEW custom pricing rule that immediately affects quote calculations. "
                "Use for a surcharge/discount tied to a specific peril, segment or condition."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "line": {
                        "type": "string",
                        "enum": ["All", "Auto", "Commercial Property", "General Liability"],
                    },
                    "adjustment": {
                        "type": "number",
                        "minimum": -0.5,
                        "maximum": 0.5,
                        "description": "Fractional adjustment, e.g. 0.08 = +8%, -0.05 = -5%",
                    },
                    "reason": {"type": "string"},
                },
                "required": ["name", "line", "adjustment", "reason"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "applyWorkflowPatch",
            "description": (
                "Deploy a named workflow patch that changes how a module behaves end-to-end. "
                "Use for fast-track, fraud-flag, pause-bind, or auto-deny style changes."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "patch": {
                        "type": "string",
                        "enum": [
                            "fast-track-small-claims",
                            "pause-new-bind",
                            "auto-deny-fraud-flag",
                            "telematics-discount",
                            "cat-event-surge-handling",
                        ],
                    },
                    "module": {
                        "type": "string",
                        "enum": ["Quotes", "Policy", "Claims", "Actuarial"],
                    },
                    "note": {"type": "string"},
                },
                "required": ["patch", "module"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "modifyCode",
            "description": (
                "Propose and stage a code-level change. Use when configuration tools cannot "
                "express the request (new field, new UI copy, new branch). Returns the staged "
                "diff which is rendered in the AI Engineer console in real time."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "file": {"type": "string", "description": "Project-relative path"},
                    "summary": {"type": "string"},
                    "diff": {"type": "string", "description": "Unified-style diff or before/after snippet"},
                    "module": {
                        "type": "string",
                        "enum": ["AI Engineer", "Quotes", "Policy", "Claims", "Actuarial"],
                    },
                },
                "required": ["file", "summary", "diff", "module"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "fetchHazardData",
            "description": (
                "Pull live hazard intelligence from US government sources: NOAA weather "
                "alerts & forecast, FEMA disaster declarations (last 24 months) and USGS "
                "earthquakes (last 30 days within 300km). Provide an address OR lat/lon. "
                "Optionally include a 2-letter US state for FEMA."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "address": {"type": "string"},
                    "lat": {"type": "number"},
                    "lon": {"type": "number"},
                    "state": {"type": "string", "description": "2-letter US state code, e.g. TX"},
                    "purpose": {
                        "type": "string",
                        "enum": ["underwriting", "claims", "both"],
                        "default": "underwriting",
                    },
                },
                "required": [],
            },
        },
    },
]


def _ok(applied: dict[str, Any], message: str) -> dict[str, Any]:
    return {"ok": True, "applied": applied, "message": message}


async def execute_tool(name: str, args: dict[str, Any]) -> dict[str, Any]:
    """Execute a single tool call and return a JSON-serializable result.

    Mirrors the ``execute`` functions of each ``tool()`` in chat.ts.
    """
    if name == "setModuleEnabled":
        module, enabled = args["module"], bool(args["enabled"])
        return _ok(
            {"kind": "moduleEnabled", "module": module, "enabled": enabled},
            f"{module} {'enabled' if enabled else 'disabled'}.",
        )

    if name == "setPremiumMultiplier":
        mult, reason = float(args["multiplier"]), args.get("reason", "")
        return _ok(
            {"kind": "premiumMultiplier", "multiplier": mult, "reason": reason},
            f"Premium multiplier set to {mult:.2f} ({reason}).",
        )

    if name == "setDefaultCoverageLevel":
        level = args["level"]
        return _ok({"kind": "defaultCoverage", "level": level}, f"Default coverage level set to {level}.")

    if name == "setDefaultAutonomy":
        autonomy = args["autonomy"]
        return _ok({"kind": "defaultAutonomy", "autonomy": autonomy}, f"Default autonomy set to {autonomy}.")

    if name == "setModuleDirective":
        module, directive = args["module"], args["directive"]
        return _ok({"kind": "directive", "module": module, "directive": directive}, f"Directive posted to {module}.")

    if name == "addPricingRule":
        name_, line, adj, reason = args["name"], args["line"], float(args["adjustment"]), args["reason"]
        pct = f"{'+' if adj >= 0 else ''}{adj * 100:.1f}%"
        return _ok(
            {"kind": "pricingRule", "name": name_, "line": line, "adjustment": adj, "reason": reason},
            f'Pricing rule "{name_}" added ({line}, {pct}) - {reason}',
        )

    if name == "applyWorkflowPatch":
        patch, module, note = args["patch"], args["module"], args.get("note", "")
        suffix = f" - {note}" if note else ""
        return _ok(
            {"kind": "workflowPatch", "patch": patch, "module": module, "note": note},
            f'Deployed "{patch}" to {module}{suffix}.',
        )

    if name == "modifyCode":
        import datetime as dt

        file, summary, diff, module = args["file"], args["summary"], args["diff"], args["module"]
        return _ok(
            {
                "kind": "codePatch",
                "file": file,
                "summary": summary,
                "diff": diff,
                "module": module,
                "stagedAt": dt.datetime.utcnow().isoformat(),
            },
            f"Code patch staged -> {file} ({summary}).",
        )

    if name == "fetchHazardData":
        purpose = args.get("purpose", "underwriting")
        j = await aggregate_hazard_data(
            address=args.get("address"),
            lat=args.get("lat"),
            lon=args.get("lon"),
            state=args.get("state"),
        )
        if not j.ok:
            return {
                "ok": False,
                "applied": {"kind": "hazardData", "purpose": purpose, "error": j.error},
                "message": f"Hazard fetch failed: {j.error}",
            }
        summary = (
            f"Hazard intel pulled - Tier: {j.risk_tier} (score {j.risk_score}). "
            f"{len(j.alerts)} active NOAA alerts, {len(j.fema_disasters)} FEMA disasters (24mo), "
            f"{len(j.earthquakes)} USGS quakes (30d)."
        )
        return {
            "ok": True,
            "applied": {
                "kind": "hazardData",
                "purpose": purpose,
                "riskTier": j.risk_tier,
                "riskScore": j.risk_score,
            },
            "message": summary,
        }

    return {"ok": False, "applied": {}, "message": f"Unknown tool {name}"}


@dataclass
class AgentEvent:
    kind: str  # "tool_start" | "tool_done" | "text_delta" | "done" | "error"
    tool: str = ""
    message: str = ""
    text: str = ""
    error: str = ""
    applied: dict[str, Any] | None = None


async def run_agent_turn(
    history: list[dict[str, str]],
    user_text: str,
    mode: str = "engineer",
    max_steps: int = 12,
) -> AsyncIterator[AgentEvent]:
    """Run one agentic turn: think -> call tools -> think -> ... -> final text.

    Yields AgentEvent objects as the loop progresses so the caller (a Reflex
    background event handler) can stream partial UI updates.
    """
    system = BUSINESS_OWNER_PROMPT if mode == "business-owner" else ENGINEER_PROMPT
    messages: list[dict[str, Any]] = [{"role": "system", "content": system}]
    messages.extend(history)
    messages.append({"role": "user", "content": user_text})

    try:
        client = get_client()
    except RuntimeError as e:
        yield AgentEvent(kind="error", error=str(e))
        return

    try:
        for _ in range(max_steps):
            resp = await client.chat.completions.create(
                model=MODEL,
                messages=messages,
                tools=TOOL_SCHEMAS,
                tool_choice="auto",
            )
            choice = resp.choices[0]
            msg = choice.message
            tool_calls = msg.tool_calls or []

            if not tool_calls:
                text = msg.content or ""
                yield AgentEvent(kind="text_delta", text=text)
                yield AgentEvent(kind="done")
                return

            messages.append(
                {
                    "role": "assistant",
                    "content": msg.content or "",
                    "tool_calls": [
                        {
                            "id": tc.id,
                            "type": "function",
                            "function": {"name": tc.function.name, "arguments": tc.function.arguments},
                        }
                        for tc in tool_calls
                    ],
                }
            )

            if msg.content:
                yield AgentEvent(kind="text_delta", text=msg.content)

            for tc in tool_calls:
                tool_name = tc.function.name
                try:
                    tool_args = json.loads(tc.function.arguments or "{}")
                except json.JSONDecodeError:
                    tool_args = {}
                yield AgentEvent(kind="tool_start", tool=tool_name)
                result = await execute_tool(tool_name, tool_args)
                yield AgentEvent(
                    kind="tool_done",
                    tool=tool_name,
                    message=result.get("message", ""),
                    applied=result.get("applied") or {},
                )
                messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": tc.id,
                        "content": json.dumps(result),
                    }
                )

        yield AgentEvent(kind="done")
    except Exception as e:  # noqa: BLE001 - surface any gateway/network error to the UI
        yield AgentEvent(kind="error", error=str(e))
