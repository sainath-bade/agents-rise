"""Builds the 5-stage Insights Agent / human-in-the-loop claims workflow.

Pure port of ``buildStages()`` in ``ClaimsLifecycle.tsx``. No I/O - just
narrative/demo data parameterized by the claim form fields.
"""

from __future__ import annotations

from agent_compass.models import ClaimStage, Hypothesis, Insight, Threshold


def build_stages(
    claimant_name: str,
    policy_number: str,
    location: str,
    estimated_amount: float,
) -> list[ClaimStage]:
    est = estimated_amount or 4800
    parts = [p.strip() for p in (location or "").split(",")]
    jurisdiction = parts[-2] if len(parts) >= 2 else "Broward County"

    return [
        ClaimStage(
            key="fnol",
            title="Stage 1 - FNOL (Intake & Triage)",
            subtitle="Assemble claimant history and litigation context at file open.",
            agent="Nova Calderon",
            role="Intake & Triage Agent",
            insights=[
                Insight(
                    label="Prior claim match - ISO ClaimSearch",
                    detail=(
                        f"Soft-tissue claim on {claimant_name} from 3 years ago (lumbar). "
                        "Distinct anatomy vs. current cervical strain."
                    ),
                    severity="warn",
                ),
                Insight(
                    label=f"Jurisdiction signal - {jurisdiction}",
                    detail="Elevated BI severity trend and litigation flag density over trailing 24 months.",
                    severity="warn",
                ),
                Insight(
                    label="Policy in-force verification",
                    detail=f"Policy {policy_number} confirmed in-force at date of loss. Coverage grants apply.",
                    severity="info",
                ),
            ],
            approve_label="Confirm triage & route to Investigation",
            reject_label="Send back - need more intake data",
            decision_prompt=(
                "Adjuster confirms severity tier and routing. Insights are advisory; the "
                "routing decision requires human sign-off before Investigation begins."
            ),
        ),
        ClaimStage(
            key="investigation",
            title="Stage 2 - Investigation",
            subtitle="Resolve interpretive tension against historical baselines.",
            agent="Rafael Okafor",
            role="Field Investigation Agent",
            insights=[
                Insight(
                    label="Comparable settlements (trailing 18 mo.)",
                    detail="Mean $16,800 - 94% of matching profiles close under $22,000.",
                    severity="info",
                ),
                Insight(
                    label="Documentation risk",
                    detail=(
                        f"{claimant_name} reports self-employment - wage-loss substantiation "
                        "is thinner than salaried baseline."
                    ),
                    severity="warn",
                ),
            ],
            hypotheses=[
                Hypothesis(
                    title="H1 - Genuine low-severity soft-tissue claim",
                    support="Injury profile, mechanism of loss, and comparable closes align with $15k-$19k band.",
                    tension="Requires accepting self-reported wage impact without independent verification.",
                ),
                Hypothesis(
                    title="H2 - Documentation-inflated exposure",
                    support="Self-employed wage-loss claims trend 22% higher when unaudited.",
                    tension=(
                        "Anatomically, prior lumbar injury is distinct from current cervical "
                        "strain - no clear stacking argument."
                    ),
                ),
            ],
            approve_label="Adopt H1 - proceed to Evaluation",
            reject_label="Adopt H2 - request wage substantiation",
            decision_prompt=(
                "The agent statistically infers. The human operationally decides. Choose which "
                "hypothesis becomes the working posture."
            ),
        ),
        ClaimStage(
            key="evaluation",
            title="Stage 3 - Evaluation",
            subtitle="Balance statistical risk against treatment reasonableness.",
            agent="Priya Hayashi",
            role="Coverage & Damage Evaluation Agent",
            insights=[
                Insight(
                    label="Treatment pattern (PT logs)",
                    detail=(
                        "16 physical-therapy visits over 5 weeks; frequency is above the 75th "
                        "percentile for similar cervical strains."
                    ),
                    severity="warn",
                ),
                Insight(
                    label="Reserve indication",
                    detail=f"Indemnity $15,500 - ALAE $1,900 - Total ~${est + 12700:,.0f} recommended.",
                    severity="info",
                ),
                Insight(
                    label="Re-opening risk",
                    detail="12% predicted - below the 20% IME threshold.",
                    severity="info",
                ),
            ],
            thresholds=[
                Threshold(name="IME threshold", status="within", note="Treatment pattern does not cross the IME trigger."),
                Threshold(name="SIU / Fraud referral", status="within", note="No red-flag pattern; SIU not warranted."),
            ],
            approve_label="Set reserves & advance to Negotiation",
            reject_label="Order IME - treatment pattern needs review",
            decision_prompt=(
                "Confirm the reserve posture or override to specialized action (IME). Both "
                "paths are logged with the evidence the agent surfaced."
            ),
        ),
        ClaimStage(
            key="negotiation",
            title="Stage 4 - Negotiation",
            subtitle="Turn undocumented mental steps into auditable options.",
            agent="Sienna Whitfield",
            role="Negotiation Agent",
            insights=[
                Insight(
                    label="Incoming demand",
                    detail="Third-party demand received on Day 31 at $24,500 - 35% above historical midpoint.",
                    severity="critical",
                ),
                Insight(
                    label="Data-backed counter-offer range",
                    detail="$16,500 - $18,000 - Target $17,000 - Walk-away $19,200.",
                    severity="info",
                ),
            ],
            thresholds=[
                Threshold(name="Defense counsel referral", status="within", note="Litigation probability 14% - below 30% referral trigger."),
                Threshold(name="Reserve authority", status="within", note="Proposed counter is inside the adjuster's authority band."),
                Threshold(name="Severity escalation", status="within", note="No escalation to supervisor required."),
            ],
            approve_label="Send $17,000 counter-offer",
            reject_label="Escalate - refer to defense counsel",
            decision_prompt=(
                "Defensive options are explicitly evaluated and ruled out rather than left as "
                "invisible mental steps. Confirm the counter or invoke escalation."
            ),
        ),
        ClaimStage(
            key="settlement",
            title="Stage 5 - Settlement",
            subtitle="From identical outcome to a fully documented decision trail.",
            agent="Marcus Brennan",
            role="Settlement & Closure Agent",
            insights=[
                Insight(
                    label="Final settlement",
                    detail="Claim settled on Day 47 at $18,400 - inside the data-backed band.",
                    severity="info",
                ),
                Insight(
                    label="Reconstructible decision state",
                    detail=(
                        "What the adjuster knew, what the agent surfaced, what alternatives "
                        "existed, and which thresholds applied are all captured."
                    ),
                    severity="info",
                ),
            ],
            approve_label="Finalize payment & close file",
            reject_label="Hold - re-open for supervisor audit",
            decision_prompt=(
                "Same financial outcome as the manual workflow, but every micro-decision is "
                "now auditable, transferable training material."
            ),
        ),
    ]
