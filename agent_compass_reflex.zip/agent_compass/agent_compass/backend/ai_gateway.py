"""OpenAI-compatible client pointed at the Lovable AI Gateway.

Mirrors ``src/lib/ai-gateway.ts`` from the original TanStack app, which used
``@ai-sdk/openai-compatible``. We use the official ``openai`` Python SDK's
``AsyncOpenAI`` client, which speaks the same wire protocol.
"""

from __future__ import annotations

import os

from openai import AsyncOpenAI

GATEWAY_BASE_URL = "https://ai.gateway.lovable.dev/v1"
MODEL = "google/gemini-3-flash-preview"


def get_client() -> AsyncOpenAI:
    key = os.environ.get("LOVABLE_API_KEY")
    if not key:
        raise RuntimeError("Missing LOVABLE_API_KEY environment variable")
    return AsyncOpenAI(
        base_url=GATEWAY_BASE_URL,
        api_key=key,
        default_headers={
            "Lovable-API-Key": key,
            "X-Lovable-AIG-SDK": "python-openai-sdk",
        },
    )
