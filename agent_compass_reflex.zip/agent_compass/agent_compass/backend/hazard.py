"""Shared hazard intelligence aggregator.

Python port of ``src/lib/hazard.server.ts``. Used by the Hazard Intelligence
panel and by the ``fetch_hazard_data`` agent tool. All network calls are
async (httpx) so this can be awaited directly from Reflex event handlers.
"""

from __future__ import annotations

import datetime as dt
from typing import Any, Optional
from urllib.parse import quote

import httpx

from agent_compass.models import (
    ForecastPeriod,
    HazardAlert,
    HazardData,
    HazardDisaster,
    HazardQuake,
)

UA = "SentinelUnderwriters/1.0 (hazard-intel; contact: ops@sentinel.example)"

SEVERITY_WEIGHT = {
    "Extreme": 40,
    "Severe": 25,
    "Moderate": 12,
    "Minor": 5,
    "Unknown": 3,
}


async def _geocode(client: httpx.AsyncClient, address: str) -> Optional[dict[str, Any]]:
    url = (
        "https://nominatim.openstreetmap.org/search"
        f"?format=json&limit=1&addressdetails=1&q={quote(address)}"
    )
    try:
        r = await client.get(url, headers={"User-Agent": UA, "Accept": "application/json"})
        if r.status_code != 200:
            return None
        data = r.json()
    except Exception:
        return None
    if not data:
        return None
    hit = data[0]
    iso = (hit.get("address") or {}).get("ISO3166-2-lvl4")
    state = iso[3:] if iso and iso.startswith("US-") else None
    return {"lat": float(hit["lat"]), "lon": float(hit["lon"]), "state": state}


async def _noaa_alerts(client: httpx.AsyncClient, lat: float, lon: float) -> list[HazardAlert]:
    try:
        r = await client.get(
            f"https://api.weather.gov/alerts/active?point={lat},{lon}",
            headers={"User-Agent": UA, "Accept": "application/geo+json"},
        )
        if r.status_code != 200:
            return []
        features = (r.json() or {}).get("features") or []
    except Exception:
        return []
    out = []
    for f in features[:10]:
        p = f.get("properties", {})
        out.append(
            HazardAlert(
                event=str(p.get("event") or ""),
                severity=str(p.get("severity") or "Unknown"),
                headline=str(p.get("headline") or ""),
                area_desc=str(p.get("areaDesc") or ""),
            )
        )
    return out


async def _noaa_forecast(
    client: httpx.AsyncClient, lat: float, lon: float
) -> tuple[str, str, list[ForecastPeriod]]:
    try:
        meta = await client.get(
            f"https://api.weather.gov/points/{lat},{lon}",
            headers={"User-Agent": UA, "Accept": "application/geo+json"},
        )
        if meta.status_code != 200:
            return "", "", []
        m = meta.json().get("properties", {}) or {}
        f_url = m.get("forecast")
        if not f_url:
            return "", "", []
        fr = await client.get(f_url, headers={"User-Agent": UA, "Accept": "application/geo+json"})
        if fr.status_code != 200:
            return "", "", []
        periods_raw = (fr.json().get("properties", {}) or {}).get("periods") or []
        periods = [
            ForecastPeriod(
                name=str(p.get("name") or ""),
                temperature=int(p.get("temperature") or 0),
                temperature_unit=str(p.get("temperatureUnit") or ""),
                wind_speed=str(p.get("windSpeed") or ""),
                short_forecast=str(p.get("shortForecast") or ""),
            )
            for p in periods_raw[:5]
        ]
        rel = (m.get("relativeLocation") or {}).get("properties") or {}
        return str(rel.get("city") or ""), str(rel.get("state") or ""), periods
    except Exception:
        return "", "", []


async def _fema_disasters(client: httpx.AsyncClient, state: str) -> list[HazardDisaster]:
    since = (dt.datetime.utcnow() - dt.timedelta(days=365 * 2)).isoformat() + "Z"
    url = (
        "https://www.fema.gov/api/open/v2/DisasterDeclarationsSummaries"
        f"?$filter=state%20eq%20'{state}'%20and%20declarationDate%20gt%20'{since}'"
        "&$orderby=declarationDate%20desc&$top=10"
        "&$select=declarationDate,incidentType,declarationTitle,designatedArea,fyDeclared"
    )
    try:
        r = await client.get(url, headers={"User-Agent": UA, "Accept": "application/json"})
        if r.status_code != 200:
            return []
        rows = (r.json() or {}).get("DisasterDeclarationsSummaries") or []
    except Exception:
        return []
    return [
        HazardDisaster(
            declaration_date=str(row.get("declarationDate") or ""),
            incident_type=str(row.get("incidentType") or ""),
            declaration_title=str(row.get("declarationTitle") or ""),
            designated_area=str(row.get("designatedArea") or ""),
        )
        for row in rows
    ]


async def _usgs_quakes(client: httpx.AsyncClient, lat: float, lon: float) -> list[HazardQuake]:
    start = (dt.datetime.utcnow() - dt.timedelta(days=30)).date().isoformat()
    url = (
        "https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson"
        f"&starttime={start}&latitude={lat}&longitude={lon}"
        "&maxradiuskm=300&minmagnitude=2.5&limit=10&orderby=magnitude"
    )
    try:
        r = await client.get(url, headers={"User-Agent": UA})
        if r.status_code != 200:
            return []
        features = (r.json() or {}).get("features") or []
    except Exception:
        return []
    return [
        HazardQuake(mag=float((f.get("properties") or {}).get("mag") or 0), place=str((f.get("properties") or {}).get("place") or ""))
        for f in features
    ]


async def aggregate_hazard_data(
    address: Optional[str] = None,
    lat: Optional[float] = None,
    lon: Optional[float] = None,
    state: Optional[str] = None,
) -> HazardData:
    async with httpx.AsyncClient(timeout=15.0) as client:
        if (lat is None or lon is None) and address:
            g = await _geocode(client, address)
            if not g:
                return HazardData(ok=False, error="Could not geocode address")
            lat, lon = g["lat"], g["lon"]
            state = state or g["state"]

        if lat is None or lon is None:
            return HazardData(ok=False, error="lat/lon or address required")

        import asyncio

        alerts_task = _noaa_alerts(client, lat, lon)
        forecast_task = _noaa_forecast(client, lat, lon)
        quakes_task = _usgs_quakes(client, lat, lon)
        disasters_task = _fema_disasters(client, state) if state else _empty_disasters()

        alerts, (f_city, f_state, periods), quakes, disasters = await asyncio.gather(
            alerts_task, forecast_task, quakes_task, disasters_task
        )

    score = 0.0
    for a in alerts:
        score += SEVERITY_WEIGHT.get(a.severity, 3)
    score += min(20, len(disasters) * 2)
    score += min(15, len(quakes) * 1.5)
    risk_tier = "High" if score >= 60 else "Elevated" if score >= 25 else "Standard"

    return HazardData(
        ok=True,
        lat=lat,
        lon=lon,
        state=state or "",
        risk_score=round(score),
        risk_tier=risk_tier,
        alerts=alerts,
        fema_disasters=disasters,
        earthquakes=quakes,
        forecast_city=f_city,
        forecast_state=f_state,
        forecast_periods=periods,
        sources=[
            "NOAA NWS api.weather.gov",
            "FEMA OpenFEMA",
            "USGS Earthquake Catalog",
            "OpenStreetMap Nominatim",
        ],
        fetched_at=dt.datetime.utcnow().isoformat(),
    )


async def _empty_disasters() -> list[HazardDisaster]:
    return []
