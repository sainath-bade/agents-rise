"""AI claim adjudication and evidence-description helpers.

Python port of ``src/routes/api/adjudicate-claim.ts`` and
``src/routes/api/describe-evidence.ts``. Image attachments are passed as
``image_url`` content parts (data URLs) which the OpenAI-compatible chat
completions API accepts directly - simpler than the original's manual
base64 -> Uint8Array conversion for the Vercel AI SDK's ImagePart/FilePart.
Non-image attachments (video/audio/other) are noted by name+type only,
since arbitrary binary file parts aren't part of the standard chat
completions content-part spec.
"""

from __future__ import annotations

from typing import Any

from agent_compass.backend.ai_gateway import MODEL, get_client

ADJUDICATE_SYSTEM = """You are a senior P&C Claims Adjuster AI assistant.
Review the First Notice of Loss (FNOL) details together with any attached evidence
(photos of damage, scene videos, recorded statements, documents) and produce a
structured adjudication recommendation.

Always respond in this format using markdown:

### Coverage Determination
(Covered / Partially Covered / Denied - short reason)

### Evidence Review
- One bullet per attachment, citing what you observed and how it supports or contradicts the claim.

### Liability & Fault
(Insured / Third party / Shared - with %)

### Reserve Recommendation
(Indemnity $, Expense $, total - based on visible damage severity)

### Fraud / Red Flags
(List any inconsistencies, or "None observed")

### Next Actions
- Concrete next steps for the adjuster (subrogation, SIU referral, repair estimate, etc.)"""

DESCRIBE_SYSTEM = """You are an experienced P&C claims intake specialist.
Given attached evidence (photos of damage, scene videos/stills, recorded statements)
and any partial FNOL context, write a clear, factual "Loss Description" paragraph
suitable for pasting into a claim intake form.

Rules:
- 3-6 sentences, plain prose, no bullet points, no markdown headers.
- Describe what is visually/audibly evident: vehicles/property involved, visible damage
  (location, severity), point of impact, environmental conditions, and any statements heard.
- Do NOT speculate on liability, coverage, or reserves.
- If evidence is insufficient, say so briefly at the end.
Return only the description text - no preamble."""


def _claim_summary(claim: dict[str, Any]) -> str:
    lines = [f"- {k}: {v}" for k, v in claim.items() if v not in (None, "")]
    return "\n".join(lines) if lines else "(none provided)"


def _attachment_parts(attachments: list[dict[str, Any]]) -> list[dict[str, Any]]:
    parts: list[dict[str, Any]] = []
    for att in attachments:
        media_type = att.get("media_type", "")
        name = att.get("name", "attachment")
        data_url = att.get("data_url", "")
        if media_type.startswith("image/") and data_url:
            parts.append({"type": "image_url", "image_url": {"url": data_url}})
            parts.append({"type": "text", "text": f"(attachment: {name}, {media_type})"})
        else:
            parts.append(
                {
                    "type": "text",
                    "text": f"(attachment: {name}, {media_type} - binary content not inlined; "
                    "described by filename/type only)",
                }
            )
    return parts


async def adjudicate_claim(
    claim: dict[str, Any], attachments: list[dict[str, Any]]
) -> tuple[bool, str]:
    """Returns (ok, recommendation_or_error)."""
    client = get_client()
    summary = _claim_summary(claim)
    content: list[dict[str, Any]] = [
        {
            "type": "text",
            "text": (
                f"Adjudicate the following claim.\n\nFNOL details:\n{summary}\n\n"
                "Attachments below - analyze each one as evidence."
            ),
        }
    ]
    content.extend(_attachment_parts(attachments))

    try:
        resp = await client.chat.completions.create(
            model=MODEL,
            messages=[
                {"role": "system", "content": ADJUDICATE_SYSTEM},
                {"role": "user", "content": content},
            ],
        )
        return True, resp.choices[0].message.content or ""
    except Exception as e:  # noqa: BLE001
        return False, str(e)


async def describe_evidence(
    claim: dict[str, Any], attachments: list[dict[str, Any]]
) -> tuple[bool, str]:
    """Returns (ok, description_or_error)."""
    if not attachments:
        return False, "No attachments provided"
    client = get_client()
    ctx = _claim_summary(claim)
    content: list[dict[str, Any]] = [
        {
            "type": "text",
            "text": (
                f"Partial FNOL context (may be empty):\n{ctx}\n\n"
                "Analyze the attached evidence and write the Loss Description."
            ),
        }
    ]
    content.extend(_attachment_parts(attachments))

    try:
        resp = await client.chat.completions.create(
            model=MODEL,
            messages=[
                {"role": "system", "content": DESCRIBE_SYSTEM},
                {"role": "user", "content": content},
            ],
        )
        return True, (resp.choices[0].message.content or "").strip()
    except Exception as e:  # noqa: BLE001
        return False, str(e)
